@echo off
REM Inicia Mis Finanzas en Windows (doble clic)
set PHP=php
where php >nul 2>nul || set PHP=C:\xampp\php\php.exe
cd /d "%~dp0backend"
if not exist vendor\autoload.php (echo Falta la carpeta vendor. Ejecuta: composer install & pause & exit /b)
start "" http://localhost:8000
echo Mis Finanzas esta corriendo en http://localhost:8000  (cierra esta ventana para detenerla)
"%PHP%" -S localhost:8000 -t public public/index.php
pause
