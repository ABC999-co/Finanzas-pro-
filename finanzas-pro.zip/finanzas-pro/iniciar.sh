#!/usr/bin/env bash
# Inicia Mis Finanzas en Mac o Linux:  ./iniciar.sh
cd "$(dirname "$0")/backend" || exit 1
[ -f vendor/autoload.php ] || composer install
echo "Mis Finanzas está corriendo en http://localhost:8000  (Ctrl+C para detener)"
php -S localhost:8000 -t public public/index.php
