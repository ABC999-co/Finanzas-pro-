# Guía de instalación · Mis Finanzas

Esta guía te lleva paso a paso. Cada paso termina con un **✅ Comprobación**: si se cumple, pasa al siguiente.

> ⏱️ **Tiempo estimado:** 10 minutos con SQLite · 15 minutos con MySQL.

---

## Índice

1. [Qué necesitas](#1-qué-necesitas)
2. [Instalación rápida en Windows con XAMPP](#2-instalación-rápida-en-windows-con-xampp-recomendada)
3. [Instalación en Mac o Linux](#3-instalación-en-mac-o-linux)
4. [Cambiar a MySQL (opcional)](#4-cambiar-a-mysql-opcional)
5. [Primer uso](#5-primer-uso)
6. [Solución de problemas](#6-solución-de-problemas)
7. [Para desarrolladores: modificar la interfaz](#7-para-desarrolladores-modificar-la-interfaz)
8. [Opcional: publicarla con Apache](#8-opcional-publicarla-con-apache)

---

## 1. Qué necesitas

| Requisito | ¿Obligatorio? | Para qué |
|---|---|---|
| **PHP 8.1 o superior** | ✅ Sí | Ejecuta el servidor de la app |
| Extensiones de PHP `pdo_sqlite` o `pdo_mysql`, y `mbstring` | ✅ Sí | Base de datos y textos con tildes |
| **MySQL / MariaDB** | ❌ Opcional | Solo si no quieres usar SQLite |
| **Node.js 20+** | ❌ Opcional | Solo si vas a modificar la interfaz |
| **Composer** | ❌ Opcional | Las librerías de PHP ya vienen incluidas en el zip |

> 💡 **SQLite o MySQL, ¿cuál elijo?**
> - **SQLite** (viene por defecto): la base de datos es un archivo que se crea solo. Sirve para probar y para presentar.
> - **MySQL**: si tu profesor lo pide o quieres verla en phpMyAdmin.
>
> Puedes empezar con SQLite y cambiar después. Solo hay que modificar una palabra (ver [sección 4](#4-cambiar-a-mysql-opcional)).

---

## 2. Instalación rápida en Windows con XAMPP (recomendada)

### Paso 1 · Instala XAMPP
Si ya lo tienes, salta al paso 2.

1. Descárgalo desde **https://www.apachefriends.org** (elige una versión con **PHP 8.1 o superior**).
2. Instálalo en la ruta por defecto: `C:\xampp`.

✅ **Comprobación:** existe el archivo `C:\xampp\php\php.exe`.

### Paso 2 · Descomprime el proyecto
1. Clic derecho sobre `finanzas-pro.zip` → **Extraer todo…**
2. Elige una carpeta fácil, por ejemplo `Documentos\finanzas-pro`.

> ⚠️ **No** la pongas dentro de `C:\xampp\htdocs`. No hace falta y puede confundir.

✅ **Comprobación:** dentro de la carpeta ves `iniciar.bat`, `backend`, `frontend` y `README.md`.

### Paso 3 · Inicia la app
1. Doble clic en **`iniciar.bat`**.
2. Se abre una ventana negra (no la cierres) y el navegador en `http://localhost:8000`.

✅ **Comprobación:** ves la pantalla **"Inicia sesión"** de Mis Finanzas.

> 🎉 ¡Ya está instalada! Sigue con el [Primer uso](#5-primer-uso).
>
> Para **apagarla**, cierra la ventana negra. Para **volver a abrirla**, doble clic otra vez en `iniciar.bat`.

---

## 3. Instalación en Mac o Linux

### Paso 1 · Instala PHP

**Mac** (con [Homebrew](https://brew.sh)):
```bash
brew install php
```

**Ubuntu / Debian:**
```bash
sudo apt install php-cli php-sqlite3 php-mysql php-mbstring
```

✅ **Comprobación:** este comando muestra `PHP 8.1` o superior.
```bash
php -v
```

### Paso 2 · Descomprime e inicia
```bash
unzip finanzas-pro.zip
```
```bash
cd finanzas-pro
```
```bash
./iniciar.sh
```

Abre **http://localhost:8000** en el navegador.

✅ **Comprobación:** ves la pantalla **"Inicia sesión"**. Para detener la app, presiona `Ctrl + C` en la terminal.

---

## 4. Cambiar a MySQL (opcional)

### Paso 1 · Enciende MySQL
- **XAMPP:** abre el **XAMPP Control Panel** y pulsa **Start** en la fila **MySQL**.
- **Mac/Linux:** inicia tu servidor MySQL o MariaDB.

✅ **Comprobación:** en XAMPP, la palabra **MySQL** se pone en verde.

### Paso 2 · Edita la configuración
Abre `backend/config.php` con cualquier editor (Bloc de notas sirve) y cambia **solo** esta línea:

```php
'driver'   => getenv('DB_DRIVER') ?: 'sqlite',
```
por:
```php
'driver'   => getenv('DB_DRIVER') ?: 'mysql',
```

Si tu MySQL tiene **contraseña** (en XAMPP por defecto no tiene), cambia también la línea de `password`:

```php
'password' => getenv('DB_PASS') !== false ? getenv('DB_PASS') : 'TU_CONTRASEÑA',
```

Los demás valores por defecto sirven para XAMPP:

| Dato | Valor |
|---|---|
| Servidor | `127.0.0.1` |
| Puerto | `3306` |
| Base de datos | `mis_finanzas` |
| Usuario | `root` |
| Contraseña | *(vacía)* |

### Paso 3 · Reinicia la app
Cierra la ventana negra y vuelve a abrir `iniciar.bat` (o `./iniciar.sh`).

> ✨ **No tienes que crear nada a mano.** La primera vez que abras la app se crean solas la base de datos `mis_finanzas`, sus 8 tablas y las categorías.

✅ **Comprobación:** abre **http://localhost/phpmyadmin**. Debe aparecer la base de datos `mis_finanzas` con estas tablas: `usuarios`, `categorias`, `ingresos`, `gastos`, `prestamos`, `abonos`, `metas` y `movimientos_ahorro`.

> 📄 Si prefieres crear las tablas tú mismo, importa `backend/database/schema.mysql.sql` y luego `backend/database/categorias.sql` desde phpMyAdmin.

---

## 5. Primer uso

1. Pulsa **Crear cuenta**, escribe tu nombre, correo y una contraseña de 8 caracteres o más.
2. Elige una de dos opciones:
   - **Empezar de cero:** sigue los 3 pasos que aparecen en pantalla (ingreso → gastos fijos → meta).
   - **Ver un ejemplo:** menú de tu cuenta (tu inicial, arriba o abajo a la izquierda) → **Cargar datos de ejemplo**.

> 💡 Los datos de ejemplo sirven para **mostrar la app en una presentación**. Cuando termines, bórralos desde el mismo menú con **Borrar todos mis datos**.

### Verla en tu celular (misma red Wi-Fi)
1. En `iniciar.bat` (o `iniciar.sh`), cambia `localhost:8000` por `0.0.0.0:8000` en la línea que empieza por `php -S` o `"%PHP%" -S`.
2. Busca la IP de tu computador. En Windows escribe `ipconfig` en una terminal y mira "Dirección IPv4", por ejemplo `192.168.1.20`.
3. En el celular abre `http://192.168.1.20:8000`.

---

## 6. Solución de problemas

| Lo que ves | Qué significa | Cómo arreglarlo |
|---|---|---|
| La ventana negra se abre y se cierra sola, o dice **"php no se reconoce"** | Windows no encuentra PHP | Revisa que exista `C:\xampp\php\php.exe`. Si XAMPP está en otra carpeta, edita `iniciar.bat` y cambia esa ruta. |
| **"Falta la carpeta vendor"** | Faltan las librerías de PHP | Vuelve a descomprimir el zip completo. O, si tienes Composer, ejecuta `composer install` dentro de `backend`. |
| **"No pude conectarme a la base de datos. Revisa config.php."** | La base de datos no responde | **Con MySQL:** revisa que esté encendido (en verde en XAMPP) y que el usuario y la contraseña de `config.php` sean correctos. **Con SQLite:** mira el siguiente error. |
| En la ventana negra aparece **"could not find driver"** | Falta la extensión de PHP para la base de datos | Abre `C:\xampp\php\php.ini`, busca `;extension=pdo_sqlite` (o `;extension=pdo_mysql`), **borra el `;`** del inicio, guarda y reinicia la app. O cambia a MySQL (sección 4). |
| **"Call to undefined function mb_substr"** | Falta la extensión `mbstring` | En `php.ini`, quita el `;` de `;extension=mbstring`. En Linux: `sudo apt install php-mbstring`. |
| **"Address already in use"** o la página no carga | El puerto 8000 está ocupado | Edita `iniciar.bat` (o `iniciar.sh`) y cambia **todos** los `8000` por `8080`. Luego abre `http://localhost:8080`. |
| **"Falta compilar el frontend"** | No está la interfaz compilada | Revisa que exista `backend/public/assets`. Si no está, ejecuta `npm run build` (ver sección 7). |
| **"Tu sesión terminó"** | Se reinició el servidor o pasó mucho tiempo | Vuelve a iniciar sesión. Tus datos siguen guardados. |
| **"Ya existe una cuenta con ese correo"** | El correo ya está registrado | Usa **Iniciar sesión** en lugar de **Crear cuenta**. |

> 🔎 **¿Otro error?** Mira la **ventana negra** (o la terminal). Ahí PHP escribe el detalle técnico de lo que falló.

### Empezar desde cero
- **SQLite:** cierra la app y borra el archivo `backend/storage/finanzas.sqlite`. Se vuelve a crear vacío.
- **MySQL:** en phpMyAdmin, elimina la base de datos `mis_finanzas`. Se vuelve a crear sola.

> ⚠️ Esto borra **todas** las cuentas y sus datos.

---

## 7. Para desarrolladores: modificar la interfaz

Solo necesitas esto si cambias archivos dentro de `frontend/`. Requiere **Node.js 20 o superior** ([nodejs.org](https://nodejs.org)).

**Terminal 1** · servidor PHP (déjalo encendido):
```bash
cd backend
```
```bash
php -S localhost:8000 -t public public/index.php
```

**Terminal 2** · interfaz con recarga automática:
```bash
cd frontend
```
```bash
npm install
```
```bash
npm run dev
```

Abre **http://localhost:5173**. Cada cambio que guardes se ve al instante.

**Cuando termines**, compila la versión final:
```bash
npm run build
```
Esto actualiza `backend/public`, y `iniciar.bat` ya mostrará tus cambios.

---

## 8. Opcional: publicarla con Apache

Para la mayoría de usos, `iniciar.bat` es suficiente. Si necesitas Apache (por ejemplo en un servidor), la app debe estar en la **raíz del dominio**, no en una subcarpeta.

1. Activa `mod_rewrite` en Apache.
2. Crea un VirtualHost cuya carpeta pública sea `backend/public`:

```apache
<VirtualHost *:80>
    ServerName misfinanzas.local
    DocumentRoot "C:/ruta/a/finanzas-pro/backend/public"
    <Directory "C:/ruta/a/finanzas-pro/backend/public">
        AllowOverride All
        Require all granted
    </Directory>
</VirtualHost>
```

3. Agrega `127.0.0.1 misfinanzas.local` a tu archivo `hosts` y abre `http://misfinanzas.local`.

> 🔒 En un servidor real usa **HTTPS**. La app marca automáticamente la cookie de sesión como segura cuando detecta HTTPS.

---

**¿Todo funcionó?** 🎉 Ya puedes usar la app o presentarla. Las tecnologías, la API y las funciones están explicadas en `README.md`.
