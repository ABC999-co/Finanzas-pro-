import { defineConfig } from 'vite'
import vue from '@vitejs/plugin-vue'
import tailwindcss from '@tailwindcss/vite'

export default defineConfig({
  plugins: [vue(), tailwindcss()],
  // En desarrollo, las llamadas a /api van al servidor PHP
  server: { proxy: { '/api': 'http://127.0.0.1:8000' } },
  // Al compilar, el resultado queda dentro del backend para servir todo junto
  build: { outDir: '../backend/public', emptyOutDir: false },
})
