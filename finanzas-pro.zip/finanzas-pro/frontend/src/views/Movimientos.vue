<script setup>
// Una sola pantalla para ingresos y gastos (cambia según "tipo")
import { ref, watch, computed } from 'vue'
import { Plus, Copy, Receipt, Wallet } from 'lucide-vue-next'
import MonthPicker from '../components/MonthPicker.vue'
import ConfirmButton from '../components/ConfirmButton.vue'
import Vacio from '../components/Vacio.vue'
import { estado, datosCambiaron, avisar } from '../lib/store.js'
import { api } from '../lib/api.js'
import { money, mesActual, fecha, nombreMes } from '../lib/format.js'
import { icono } from '../lib/icons.js'

const props = defineProps({ tipo: String })
const esGasto = computed(() => props.tipo === 'gasto')
const ruta = computed(() => (esGasto.value ? '/gastos' : '/ingresos'))
const mes = ref(mesActual())
const filtro = ref('todos')
const lista = ref(null)

const cargar = async () => { try { lista.value = await api.get(`${ruta.value}?mes=${mes.value}`) } catch (e) { avisar(e.message, 'error') } }
watch([mes, () => estado.version], cargar, { immediate: true })

const suma = (c) => (lista.value || []).filter((x) => !c || x.clase === c).reduce((a, x) => a + x.monto, 0)
const visibles = computed(() => (lista.value || []).filter((x) => filtro.value === 'todos' || x.clase === filtro.value))
// Agrupa por día para que la lista sea fácil de recorrer
const grupos = computed(() => {
  const g = new Map()
  for (const x of visibles.value) { if (!g.has(x.fecha)) g.set(x.fecha, []); g.get(x.fecha).push(x) }
  return [...g.entries()]
})

async function eliminar(x) {
  try { await api.del(`${ruta.value}/${x.id}`); await datosCambiaron(esGasto.value ? 'Gasto eliminado. El dinero volvió a tu disponible.' : 'Ingreso eliminado.') }
  catch (e) { avisar(e.message, 'error') }
}
async function copiarFijos() {
  try { const r = await api.post('/gastos/copiar-fijos', { mes: mes.value }); await datosCambiaron(`Copiamos ${r.copiados} gastos fijos por ${money(r.total)}.`) }
  catch (e) { avisar(e.message, 'error') }
}
</script>

<template>
  <div class="grid gap-5">
    <div class="flex flex-wrap items-end justify-between gap-3">
      <div>
        <h1 class="text-2xl font-bold md:text-3xl">{{ esGasto ? 'Gastos' : 'Ingresos' }}</h1>
        <p class="text-muted">{{ esGasto ? 'Solo puedes gastar lo que tienes disponible.' : 'Todo el dinero que entra.' }}</p>
      </div>
      <div class="flex flex-wrap items-center gap-2">
        <MonthPicker v-model="mes" />
        <button class="btn btn-primary hidden md:inline-flex" @click="estado.hoja = { tipo }"><Plus :size="18" /> {{ esGasto ? 'Nuevo gasto' : 'Nuevo ingreso' }}</button>
      </div>
    </div>

    <div class="grid grid-cols-3 gap-3">
      <button v-for="[c, t] in [['todos', 'Total'], ['fijo', 'Fijos'], ['variable', 'Variables']]" :key="c"
              class="card min-w-0 p-3.5 text-left transition-colors md:p-4" :class="filtro === c ? '!border-accent ring-2 ring-accent-soft' : 'hover:bg-surface-2'"
              :aria-pressed="filtro === c" @click="filtro = c">
        <span class="text-xs font-semibold text-muted md:text-sm">{{ t }}</span>
        <span class="mt-1 block font-display text-base font-bold [overflow-wrap:anywhere] md:text-xl" :class="c === 'todos' ? (esGasto ? 'text-gas' : 'text-ing') : ''">{{ money(suma(c === 'todos' ? null : c)) }}</span>
      </button>
    </div>

    <div v-if="esGasto" class="flex flex-wrap items-center justify-between gap-3 rounded-2xl bg-surface-2 px-4 py-3">
      <p class="flex items-center gap-2 text-sm"><Wallet :size="16" class="text-muted" /> Disponible para gastar: <strong>{{ money(estado.saldo.disponible) }}</strong></p>
      <button class="btn btn-sm" @click="copiarFijos"><Copy :size="15" /> Copiar fijos del mes anterior</button>
    </div>

    <section class="card min-w-0 p-2 md:p-3">
      <div v-if="lista === null" class="grid gap-2 p-3"><div v-for="i in 4" :key="i" class="h-14 animate-pulse rounded-xl bg-surface-2"></div></div>
      <div v-else-if="grupos.length" v-auto-animate>
        <div v-for="[f, items] in grupos" :key="f">
          <p class="eyebrow px-3 pb-1 pt-3">{{ fecha(f) }}</p>
          <ul v-auto-animate>
            <li v-for="x in items" :key="x.id" class="group flex items-center gap-3 rounded-xl px-3 py-2.5 hover:bg-surface-2">
              <span class="grid size-10 shrink-0 place-items-center rounded-xl" :class="esGasto ? 'bg-gas-soft text-gas' : 'bg-ing-soft text-ing'"><component :is="icono(x.icono)" :size="18" /></span>
              <div class="min-w-0 flex-1">
                <p class="truncate font-semibold">{{ x.categoria }}</p>
                <p class="flex items-center gap-1.5 truncate text-xs text-muted">
                  <span class="rounded-full px-1.5 py-px font-bold" :class="x.clase === 'fijo' ? 'bg-accent-soft text-fg' : 'bg-surface-2 text-fg'">{{ x.clase === 'fijo' ? 'Fijo' : 'Variable' }}</span>
                  <span class="truncate">{{ x.descripcion }}</span>
                </p>
              </div>
              <span class="shrink-0 font-display font-semibold" :class="esGasto ? '' : 'text-ing'">{{ esGasto ? '−' : '+' }} {{ money(x.monto) }}</span>
              <ConfirmButton compacto class="!border-transparent md:opacity-0 md:group-hover:opacity-100 md:focus:opacity-100" texto="Eliminar" confirmar="¿Eliminar?" @confirmado="eliminar(x)" />
            </li>
          </ul>
        </div>
      </div>
      <Vacio v-else :icono="Receipt" :titulo="`Sin ${esGasto ? 'gastos' : 'ingresos'}${filtro !== 'todos' ? ' ' + filtro + 's' : ''} en ${nombreMes(mes).toLowerCase()}`"
             :texto="esGasto ? 'Registra en qué se va tu dinero para entenderlo mejor.' : 'Registra lo que recibes: salario, marañas o trabajos extra.'">
        <button class="btn btn-primary btn-sm" @click="estado.hoja = { tipo }"><Plus :size="16" /> {{ esGasto ? 'Registrar gasto' : 'Registrar ingreso' }}</button>
      </Vacio>
    </section>
  </div>
</template>
