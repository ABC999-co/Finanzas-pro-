<script setup>
import { ref, watch, computed } from 'vue'
import { Plus, PiggyBank, Trophy } from 'lucide-vue-next'
import ConfirmButton from '../components/ConfirmButton.vue'
import Vacio from '../components/Vacio.vue'
import { estado, datosCambiaron, avisar } from '../lib/store.js'
import { api } from '../lib/api.js'
import { money } from '../lib/format.js'

const metas = ref(null)
const cargar = async () => { try { metas.value = await api.get('/metas') } catch (e) { avisar(e.message, 'error') } }
watch(() => estado.version, cargar, { immediate: true })
const pct = (m) => Math.min(100, Math.round((m.saldo / m.objetivo) * 100))
const total = computed(() => (metas.value || []).reduce((a, m) => a + m.saldo, 0))
const R = 34, C = 2 * Math.PI * R
async function eliminar(m) {
  try { await api.del(`/metas/${m.id}`); await datosCambiaron(m.saldo > 0 ? `Meta eliminada. ${money(m.saldo)} volvieron a tu disponible.` : 'Meta eliminada.') }
  catch (e) { avisar(e.message, 'error') }
}
</script>

<template>
  <div class="grid gap-5">
    <div class="flex flex-wrap items-end justify-between gap-3">
      <div><h1 class="text-2xl font-bold md:text-3xl">Ahorros</h1><p class="text-muted">Separa dinero de tu disponible para lo que te importa.</p></div>
      <button class="btn btn-primary hidden md:inline-flex" @click="estado.hoja = { tipo: 'meta' }"><Plus :size="18" /> Nueva meta</button>
    </div>

    <div class="card flex flex-wrap items-center gap-4 p-5">
      <span class="grid size-12 place-items-center rounded-2xl bg-aho-soft text-aho"><PiggyBank :size="24" /></span>
      <div class="flex-1"><p class="text-sm font-semibold text-muted">Total ahorrado</p><p class="font-display text-2xl font-bold">{{ money(total) }}</p></div>
      <p class="text-sm text-muted">Disponible para guardar: <strong class="text-fg">{{ money(estado.saldo.disponible) }}</strong></p>
    </div>

    <div v-if="metas === null" class="grid gap-3 md:grid-cols-2"><div v-for="i in 2" :key="i" class="h-44 animate-pulse rounded-2xl bg-surface-2"></div></div>
    <div v-else-if="metas.length" class="grid gap-3 md:grid-cols-2 xl:grid-cols-3" v-auto-animate>
      <article v-for="m in metas" :key="m.id" class="card flex min-w-0 flex-col gap-4 p-5">
        <div class="flex items-center gap-4">
          <div class="relative size-20 shrink-0">
            <svg viewBox="0 0 80 80" class="size-full -rotate-90" role="img" :aria-label="`${pct(m)}% de la meta`">
              <circle cx="40" cy="40" :r="R" fill="none" stroke="var(--surface-2)" stroke-width="8" />
              <circle cx="40" cy="40" :r="R" fill="none" stroke="var(--aho)" stroke-width="8" stroke-linecap="round"
                      :stroke-dasharray="`${(pct(m) / 100) * C} ${C}`" class="transition-[stroke-dasharray] duration-700" />
            </svg>
            <span class="absolute inset-0 grid place-items-center font-display text-sm font-bold">
              <Trophy v-if="pct(m) >= 100" :size="22" class="text-aho" /><template v-else>{{ pct(m) }}%</template>
            </span>
          </div>
          <div class="min-w-0">
            <p class="truncate font-bold">{{ m.nombre }}</p>
            <p class="font-display text-lg font-bold">{{ money(m.saldo) }}</p>
            <p class="text-xs text-muted">de {{ money(m.objetivo) }}<template v-if="m.saldo < m.objetivo"> · faltan {{ money(m.objetivo - m.saldo) }}</template></p>
          </div>
        </div>
        <p v-if="pct(m) >= 100" class="rounded-xl bg-aho-soft px-3 py-2 text-sm font-semibold text-aho">¡Lo lograste! Meta cumplida.</p>
        <div class="mt-auto flex flex-wrap gap-2">
          <button class="btn btn-sm btn-primary" @click="estado.hoja = { tipo: 'ahorro', meta: m, accion: 'deposito' }">Guardar</button>
          <button class="btn btn-sm" :disabled="m.saldo <= 0" @click="estado.hoja = { tipo: 'ahorro', meta: m, accion: 'retiro' }">Retirar</button>
          <ConfirmButton class="ml-auto" compacto texto="Eliminar meta" confirmar="¿Eliminar?" @confirmado="eliminar(m)" />
        </div>
      </article>
    </div>
    <div v-else class="card">
      <Vacio :icono="PiggyBank" titulo="Aún no tienes metas" texto="Una meta te ayuda a separar dinero sin gastarlo por accidente.">
        <button class="btn btn-primary btn-sm" @click="estado.hoja = { tipo: 'meta' }"><Plus :size="16" /> Crear mi primera meta</button>
      </Vacio>
    </div>
  </div>
</template>
