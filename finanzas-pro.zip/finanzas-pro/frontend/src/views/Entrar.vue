<script setup>
import { ref, computed } from 'vue'
import { useRouter } from 'vue-router'
import { Eye, EyeOff, ShieldCheck, Link2, Smartphone } from 'lucide-vue-next'
import { estado, cargarDatosBase, avisar } from '../lib/store.js'
import { api } from '../lib/api.js'
const router = useRouter()
const modo = ref('login')
const nombre = ref(''), email = ref(''), password = ref(''), ver = ref(false), enviando = ref(false), error = ref('')
const esRegistro = computed(() => modo.value === 'registro')

async function enviar() {
  error.value = ''
  enviando.value = true
  try {
    const u = await api.post(esRegistro.value ? '/auth/registro' : '/auth/login', { nombre: nombre.value, email: email.value, password: password.value })
    estado.usuario = u
    await cargarDatosBase()
    avisar(esRegistro.value ? `¡Bienvenido, ${u.nombre}! Empecemos.` : `Hola de nuevo, ${u.nombre}.`)
    router.replace('/')
  } catch (e) { error.value = e.message } finally { enviando.value = false }
}
const puntos = [
  [Link2, 'Todo conectado', 'Solo gastas, prestas o ahorras lo que de verdad tienes.'],
  [ShieldCheck, 'Tus datos protegidos', 'Contraseña cifrada y sesión segura.'],
  [Smartphone, 'En cualquier pantalla', 'Celular, tablet o computador.'],
]
</script>

<template>
  <div class="grid min-h-dvh lg:grid-cols-[1.1fr_1fr]">
    <section class="relative hidden overflow-hidden bg-accent p-12 text-accent-ink lg:flex lg:flex-col lg:justify-between">
      <div class="flex items-center gap-2.5 font-display text-lg font-bold"><span class="grid size-9 place-items-center rounded-xl bg-white/20">$</span> Mis Finanzas</div>
      <div class="relative z-10 max-w-md">
        <h1 class="text-4xl font-bold leading-tight">Sabe siempre cuánto tienes disponible.</h1>
        <p class="mt-4 text-lg opacity-90">Ingresos, gastos, préstamos y ahorros en un solo lugar, conectados a un solo número.</p>
        <ul class="mt-10 grid gap-5">
          <li v-for="[I, t, d] in puntos" :key="t" class="flex gap-3.5">
            <span class="grid size-10 shrink-0 place-items-center rounded-xl bg-white/15"><component :is="I" :size="20" /></span>
            <span><span class="block font-bold">{{ t }}</span><span class="block opacity-85">{{ d }}</span></span>
          </li>
        </ul>
      </div>
      <p class="text-sm opacity-75">Hecho para Colombia · valores en pesos (COP)</p>
      <div class="pointer-events-none absolute -bottom-32 -right-24 size-[28rem] rounded-full border-[48px] border-white/10"></div>
    </section>

    <section class="flex items-center justify-center py-10 pl-[max(16px,env(safe-area-inset-left))] pr-[max(16px,env(safe-area-inset-right))]">
      <div class="w-full max-w-sm">
        <div class="mb-8 flex items-center gap-2.5 font-display text-lg font-bold lg:hidden"><span class="grid size-9 place-items-center rounded-xl bg-accent text-accent-ink">$</span> Mis Finanzas</div>
        <h2 class="text-2xl font-bold">{{ esRegistro ? 'Crea tu cuenta' : 'Inicia sesión' }}</h2>
        <p class="mt-1 text-muted">{{ esRegistro ? 'Te toma menos de un minuto.' : 'Qué bueno verte otra vez.' }}</p>

        <div class="mt-6 grid grid-cols-2 gap-1 rounded-2xl bg-surface-2 p-1">
          <button v-for="[m, t] in [['login', 'Iniciar sesión'], ['registro', 'Crear cuenta']]" :key="m" type="button"
                  class="rounded-xl py-2 text-sm font-bold transition-colors" :class="modo === m ? 'bg-surface shadow-card' : 'text-muted'"
                  :aria-pressed="modo === m" @click="modo = m; error = ''">{{ t }}</button>
        </div>

        <form class="mt-6 grid gap-4" @submit.prevent="enviar">
          <div v-if="esRegistro"><label class="label" for="r-nombre">Tu nombre</label><input id="r-nombre" v-model="nombre" class="input" autocomplete="given-name" required /></div>
          <div><label class="label" for="r-email">Correo</label><input id="r-email" v-model="email" type="email" class="input" autocomplete="email" required /></div>
          <div>
            <label class="label" for="r-pass">Contraseña</label>
            <div class="relative">
              <input id="r-pass" v-model="password" :type="ver ? 'text' : 'password'" class="input pr-11" :autocomplete="esRegistro ? 'new-password' : 'current-password'" required :minlength="esRegistro ? 8 : undefined" />
              <button type="button" class="absolute right-2 top-1/2 -translate-y-1/2 rounded-lg p-1.5 text-muted hover:bg-surface-2" :aria-label="ver ? 'Ocultar contraseña' : 'Mostrar contraseña'" @click="ver = !ver">
                <component :is="ver ? EyeOff : Eye" :size="18" />
              </button>
            </div>
            <p v-if="esRegistro" class="mt-1.5 text-xs text-muted">Mínimo 8 caracteres.</p>
          </div>
          <p v-if="error" class="rounded-xl bg-danger-soft px-3 py-2.5 text-sm font-semibold text-danger" role="alert">{{ error }}</p>
          <button class="btn btn-primary mt-1 w-full py-3" :disabled="enviando">{{ enviando ? 'Un momento…' : esRegistro ? 'Crear cuenta' : 'Entrar' }}</button>
        </form>
      </div>
    </section>
  </div>
</template>
