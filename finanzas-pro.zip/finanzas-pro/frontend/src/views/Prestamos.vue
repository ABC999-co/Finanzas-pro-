<script setup>
import { ref, watch, computed } from 'vue'
import { Plus, HandCoins, CircleCheck } from 'lucide-vue-next'
import ConfirmButton from '../components/ConfirmButton.vue'
import Vacio from '../components/Vacio.vue'
import { estado, datosCambiaron, avisar } from '../lib/store.js'
import { api } from '../lib/api.js'
import { money, fecha } from '../lib/format.js'

const lista = ref(null)
const filtro = ref('pendientes')
const cargar = async () => { try { lista.value = await api.get('/prestamos') } catch (e) { avisar(e.message, 'error') } }
watch(() => estado.version, cargar, { immediate: true })
const visibles = computed(() => (lista.value || []).filter((p) => (filtro.value === 'pendientes' ? p.pendiente > 0 : p.pendiente <= 0)))
const total = (k) => (lista.value || []).reduce((a, p) => a + p[k], 0)
const pct = (p) => Math.round(((p.monto - p.pendiente) / p.monto) * 100)
async function eliminar(p) {
  try { await api.del(`/prestamos/${p.id}`); await datosCambiaron('Préstamo eliminado.') } catch (e) { avisar(e.message, 'error') }
}
</script>

<template>
  <div class="grid gap-5">
    <div class="flex flex-wrap items-end justify-between gap-3">
      <div><h1 class="text-2xl font-bold md:text-3xl">Préstamos</h1><p class="text-muted">Lo que prestas sale de tu disponible y vuelve cuando te pagan.</p></div>
      <button class="btn btn-primary hidden md:inline-flex" @click="estado.hoja = { tipo: 'prestamo' }"><Plus :size="18" /> Prestar dinero</button>
    </div>

    <div class="grid grid-cols-3 gap-3">
      <div class="card min-w-0 p-3.5 md:p-4"><p class="text-xs font-semibold text-muted md:text-sm">Te deben</p><p class="mt-1 font-display text-base font-bold text-pre [overflow-wrap:anywhere] md:text-xl">{{ money(total('pendiente')) }}</p></div>
      <div class="card min-w-0 p-3.5 md:p-4"><p class="text-xs font-semibold text-muted md:text-sm">Prestado</p><p class="mt-1 font-display text-base font-bold [overflow-wrap:anywhere] md:text-xl">{{ money(total('monto')) }}</p></div>
      <div class="card min-w-0 p-3.5 md:p-4"><p class="text-xs font-semibold text-muted md:text-sm">Recuperado</p><p class="mt-1 font-display text-base font-bold [overflow-wrap:anywhere] md:text-xl">{{ money(total('monto') - total('pendiente')) }}</p></div>
    </div>

    <div class="inline-grid w-fit grid-cols-2 gap-1 rounded-2xl bg-surface-2 p-1">
      <button v-for="[f, t] in [['pendientes', 'Pendientes'], ['pagados', 'Pagados']]" :key="f" class="rounded-xl px-4 py-1.5 text-sm font-bold"
              :class="filtro === f ? 'bg-surface shadow-card' : 'text-muted'" :aria-pressed="filtro === f" @click="filtro = f">{{ t }}</button>
    </div>

    <div v-if="lista === null" class="grid gap-3 md:grid-cols-2"><div v-for="i in 2" :key="i" class="h-40 animate-pulse rounded-2xl bg-surface-2"></div></div>
    <div v-else-if="visibles.length" class="grid gap-3 md:grid-cols-2" v-auto-animate>
      <article v-for="p in visibles" :key="p.id" class="card flex min-w-0 flex-col gap-3 p-4">
        <div class="flex items-start gap-3">
          <span class="grid size-11 shrink-0 place-items-center rounded-full bg-pre-soft font-display text-lg font-bold text-pre">{{ p.persona.charAt(0).toUpperCase() }}</span>
          <div class="min-w-0 flex-1">
            <p class="truncate font-bold">{{ p.persona }}</p>
            <p class="text-xs text-muted">Le prestaste {{ money(p.monto) }} · {{ fecha(p.fecha) }}</p>
            <p v-if="p.nota" class="mt-0.5 truncate text-xs text-muted">“{{ p.nota }}”</p>
          </div>
          <div class="text-right">
            <p v-if="p.pendiente > 0" class="font-display font-bold">{{ money(p.pendiente) }}</p>
            <p v-if="p.pendiente > 0" class="text-xs text-muted">por cobrar</p>
            <p v-else class="flex items-center gap-1 text-sm font-bold text-ok"><CircleCheck :size="16" /> Pagado</p>
          </div>
        </div>
        <div>
          <div class="mb-1 flex justify-between text-xs text-muted"><span>Te ha pagado {{ pct(p) }}%</span><span>{{ p.abonos.length }} {{ p.abonos.length === 1 ? 'abono' : 'abonos' }}</span></div>
          <div class="h-2 overflow-hidden rounded-full bg-surface-2"><div class="h-full rounded-full bg-pre transition-[width] duration-500" :style="{ width: pct(p) + '%' }"></div></div>
        </div>
        <ul v-if="p.abonos.length" class="flex flex-wrap gap-1.5 text-xs">
          <li v-for="a in p.abonos" :key="a.id" class="rounded-full bg-surface-2 px-2 py-0.5">{{ money(a.monto) }} · {{ fecha(a.fecha) }}</li>
        </ul>
        <div class="mt-auto flex flex-wrap gap-2">
          <button v-if="p.pendiente > 0" class="btn btn-sm btn-primary" @click="estado.hoja = { tipo: 'abono', prestamo: p }">Registrar pago</button>
          <ConfirmButton @confirmado="eliminar(p)" />
        </div>
      </article>
    </div>
    <div v-else class="card">
      <Vacio :icono="HandCoins" :titulo="filtro === 'pendientes' ? 'Nadie te debe dinero' : 'Aún no hay préstamos pagados'"
             :texto="filtro === 'pendientes' ? 'Si le prestas a alguien, regístralo aquí para no olvidarlo.' : 'Cuando te paguen completo, aparecerán aquí.'">
        <button v-if="filtro === 'pendientes'" class="btn btn-primary btn-sm" @click="estado.hoja = { tipo: 'prestamo' }"><Plus :size="16" /> Prestar dinero</button>
      </Vacio>
    </div>
  </div>
</template>
