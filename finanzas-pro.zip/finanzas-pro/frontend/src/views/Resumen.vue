<script setup>
import { ref, watch, computed } from 'vue'
import { ArrowDownLeft, ArrowUpRight, HandCoins, PiggyBank, Copy, Sparkles, Receipt, Equal, Minus } from 'lucide-vue-next'
import MonthPicker from '../components/MonthPicker.vue'
import DonutChart from '../components/DonutChart.vue'
import TrendChart from '../components/TrendChart.vue'
import CategoryBars from '../components/CategoryBars.vue'
import Vacio from '../components/Vacio.vue'
import { estado, datosCambiaron, avisar } from '../lib/store.js'
import { api } from '../lib/api.js'
import { money, mesActual, nombreMes, moverMes, fecha } from '../lib/format.js'

const mes = ref(mesActual())
const r = ref(null)
const cargar = async () => { try { r.value = await api.get(`/resumen?mes=${mes.value}`) } catch (e) { avisar(e.message, 'error') } }
watch([mes, () => estado.version], cargar, { immediate: true })

const t = computed(() => r.value?.totales)
const vacio = computed(() => t.value && !t.value.ingresos && !t.value.gastos)
const saludo = computed(() => { const h = new Date().getHours(); return h < 12 ? 'Buenos días' : h < 19 ? 'Buenas tardes' : 'Buenas noches' })
const partes = computed(() => t.value ? [
  { nombre: 'Gastado', valor: t.value.gastos, color: 'var(--gas)' },
  { nombre: 'Ahorrado', valor: t.value.ahorrado, color: 'var(--aho)' },
  { nombre: 'Prestado', valor: t.value.porCobrar, color: 'var(--pre)' },
  { nombre: 'Disponible', valor: Math.max(t.value.disponible, 0), color: 'var(--disp)' },
] : [])
const mesAnterior = computed(() => r.value?.tendencia?.at(-2))
const sugerirCopia = computed(() => r.value && mes.value === mesActual() && r.value.delMes.gastosFijos === 0 && mesAnterior.value?.gastos > 0)
const totalGastosMes = computed(() => r.value ? r.value.delMes.gastosFijos + r.value.delMes.gastosVariables : 0)
const icono = { ingreso: ArrowDownLeft, gasto: ArrowUpRight, prestamo: HandCoins, abono: HandCoins, deposito: PiggyBank, retiro: PiggyBank }
const estilo = { ingreso: 'bg-ing-soft text-ing', abono: 'bg-ing-soft text-ing', gasto: 'bg-gas-soft text-gas', prestamo: 'bg-pre-soft text-pre', deposito: 'bg-aho-soft text-aho', retiro: 'bg-aho-soft text-aho' }
const entra = (tipo) => ['ingreso', 'abono', 'retiro'].includes(tipo)

async function copiarFijos() {
  try { const x = await api.post('/gastos/copiar-fijos', { mes: mes.value }); await datosCambiaron(`Copiamos ${x.copiados} gastos fijos por ${money(x.total)}.`) }
  catch (e) { avisar(e.message, 'error') }
}
async function ejemplo() { try { await api.post('/demo'); await datosCambiaron('Datos de ejemplo cargados.') } catch (e) { avisar(e.message, 'error') } }
const abrir = (tipo) => (estado.hoja = { tipo })
</script>

<template>
  <div class="grid gap-5">
    <div class="flex flex-wrap items-end justify-between gap-3">
      <div>
        <p class="text-muted">{{ saludo }}, {{ estado.usuario.nombre }}</p>
        <h1 class="text-2xl font-bold md:text-3xl">Tu resumen</h1>
      </div>
      <MonthPicker v-model="mes" />
    </div>

    <template v-if="r">
      <!-- Primeros pasos -->
      <div v-if="vacio" class="card p-6">
        <p class="eyebrow">Primeros pasos</p>
        <h2 class="mt-1 text-xl font-bold">Empecemos con 3 pasos cortos</h2>
        <ol class="mt-4 grid gap-3 sm:grid-cols-3">
          <li v-for="(p, i) in [['Registra tu ingreso', 'Tu salario o lo que recibiste.', 'ingreso'], ['Anota tus gastos fijos', 'Arriendo, servicios, internet.', 'gasto'], ['Crea una meta', 'Algo para lo que quieras ahorrar.', 'meta']]" :key="i"
              class="flex flex-col gap-2 rounded-2xl border border-line p-4">
            <span class="grid size-7 place-items-center rounded-full bg-accent-soft text-sm font-bold">{{ i + 1 }}</span>
            <span class="font-bold">{{ p[0] }}</span><span class="text-sm text-muted">{{ p[1] }}</span>
            <button class="btn btn-sm mt-auto" :class="i === 0 ? 'btn-primary' : ''" :disabled="i > 0 && !t.ingresos" @click="abrir(p[2])">Hacerlo</button>
          </li>
        </ol>
        <button class="mt-4 inline-flex items-center gap-1.5 text-sm font-semibold text-accent hover:underline" @click="ejemplo"><Sparkles :size="15" /> O mira cómo funciona con datos de ejemplo</button>
      </div>

      <!-- Disponible: el número que conecta todo -->
      <section class="relative overflow-hidden rounded-3xl bg-accent p-6 text-accent-ink md:p-8">
        <p class="text-sm font-semibold opacity-85">Dinero disponible ahora</p>
        <p class="mt-1 font-display text-4xl font-bold md:text-5xl">{{ money(t.disponible) }}</p>
        <p class="mt-2 max-w-md opacity-90">Es lo que puedes gastar, prestar o ahorrar sin pasarte.</p>
        <div class="mt-5 flex flex-wrap items-center gap-x-2 gap-y-1 text-sm opacity-90">
          <span>Recibido {{ money(t.ingresos) }}</span><Minus :size="14" />
          <span>Gastado {{ money(t.gastos) }}</span><Minus :size="14" />
          <span>Prestado {{ money(t.porCobrar) }}</span><Minus :size="14" />
          <span>Ahorrado {{ money(t.ahorrado) }}</span><Equal :size="14" />
          <strong>{{ money(t.disponible) }}</strong>
        </div>
        <div class="mt-5 flex flex-wrap gap-2">
          <button class="btn !border-white/30 !bg-white/15 !text-accent-ink hover:!bg-white/25" @click="abrir('ingreso')"><ArrowDownLeft :size="17" /> Ingreso</button>
          <button class="btn !border-white/30 !bg-white/15 !text-accent-ink hover:!bg-white/25" @click="abrir('gasto')"><ArrowUpRight :size="17" /> Gasto</button>
        </div>
        <div class="pointer-events-none absolute -right-16 -top-16 size-64 rounded-full border-[36px] border-white/10"></div>
      </section>

      <!-- Sugerencia útil del mes -->
      <div v-if="sugerirCopia" class="card flex flex-wrap items-center gap-3 p-4">
        <span class="grid size-10 place-items-center rounded-xl bg-gas-soft text-gas"><Copy :size="18" /></span>
        <div class="min-w-0 flex-1"><p class="font-bold">¿Copiamos tus gastos fijos de {{ nombreMes(moverMes(mes, -1)).split(' ')[0].toLowerCase() }}?</p>
          <p class="text-sm text-muted">Arriendo, servicios y demás, con un toque.</p></div>
        <button class="btn btn-sm" @click="copiarFijos">Copiar gastos fijos</button>
      </div>

      <!-- Indicadores del mes -->
      <div class="grid grid-cols-2 gap-3 lg:grid-cols-4">
        <div v-for="k in [
            ['Ingresos del mes', r.delMes.ingresosFijos + r.delMes.ingresosVariables, `Fijos ${money(r.delMes.ingresosFijos)} · Variables ${money(r.delMes.ingresosVariables)}`, ArrowDownLeft, 'bg-ing-soft text-ing'],
            ['Gastos del mes', totalGastosMes, `Fijos ${money(r.delMes.gastosFijos)} · Variables ${money(r.delMes.gastosVariables)}`, ArrowUpRight, 'bg-gas-soft text-gas'],
            ['Te deben', t.porCobrar, 'Préstamos por cobrar', HandCoins, 'bg-pre-soft text-pre'],
            ['Ahorrado', t.ahorrado, 'En todas tus metas', PiggyBank, 'bg-aho-soft text-aho']]" :key="k[0]" class="card min-w-0 p-4">
          <div class="flex items-center gap-2"><span class="grid size-7 place-items-center rounded-lg" :class="k[4]"><component :is="k[3]" :size="15" /></span><span class="text-sm font-semibold text-muted">{{ k[0] }}</span></div>
          <p class="mt-2 font-display text-xl font-bold [overflow-wrap:anywhere]">{{ money(k[1]) }}</p>
          <p class="mt-0.5 text-xs text-muted">{{ k[2] }}</p>
        </div>
      </div>

      <div class="grid gap-5 lg:grid-cols-2">
        <section class="card min-w-0 p-5">
          <h2 class="font-semibold">¿A dónde se ha ido tu dinero?</h2>
          <p class="mb-4 text-sm text-muted">De todo lo que has recibido ({{ money(t.ingresos) }})</p>
          <DonutChart :partes="partes" :total="t.ingresos" />
        </section>
        <section class="card min-w-0 p-5">
          <h2 class="font-semibold">Últimos 6 meses</h2>
          <p class="mb-3 text-sm text-muted">Toca o pasa el cursor por un mes para ver el detalle</p>
          <TrendChart :datos="r.tendencia" />
        </section>
      </div>

      <div class="grid gap-5 lg:grid-cols-[1.2fr_1fr]">
        <section class="card min-w-0 p-5">
          <h2 class="font-semibold">Gastos de {{ nombreMes(mes).toLowerCase() }}</h2>
          <p class="mb-4 text-sm text-muted">Total {{ money(totalGastosMes) }}, de mayor a menor</p>
          <CategoryBars v-if="r.gastosPorCategoria.length" :items="r.gastosPorCategoria.slice(0, 7)" :total="totalGastosMes" />
          <Vacio v-else :icono="Receipt" titulo="Sin gastos este mes" texto="Cuando registres un gasto, verás aquí en qué se va tu dinero." />
        </section>
        <section class="card min-w-0 p-5">
          <div class="mb-2 flex items-center justify-between"><h2 class="font-semibold">Últimos movimientos</h2></div>
          <ul v-if="r.recientes.length" class="divide-y divide-line" v-auto-animate>
            <li v-for="m in r.recientes" :key="m.tipo + m.id" class="flex items-center gap-3 py-2.5">
              <span class="grid size-9 shrink-0 place-items-center rounded-xl" :class="estilo[m.tipo]"><component :is="icono[m.tipo]" :size="16" /></span>
              <div class="min-w-0 flex-1"><p class="truncate font-semibold">{{ m.titulo }}</p><p class="truncate text-xs text-muted">{{ m.detalle || '—' }} · {{ fecha(m.fecha) }}</p></div>
              <span class="shrink-0 font-display font-semibold" :class="entra(m.tipo) ? 'text-ing' : ''">{{ entra(m.tipo) ? '+' : '−' }} {{ money(m.monto) }}</span>
            </li>
          </ul>
          <Vacio v-else :icono="Receipt" titulo="Nada por aquí todavía" texto="Tus movimientos aparecerán aquí." />
        </section>
      </div>
    </template>
    <div v-else class="grid gap-4"><div v-for="i in 3" :key="i" class="h-32 animate-pulse rounded-3xl bg-surface-2"></div></div>
  </div>
</template>
