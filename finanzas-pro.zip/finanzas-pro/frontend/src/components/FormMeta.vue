<script setup>
import { computed, ref } from 'vue'
import MoneyInput from './MoneyInput.vue'
import { datosCambiaron, avisar } from '../lib/store.js'
import { api } from '../lib/api.js'
const emit = defineEmits(['listo'])
const nombre = ref(''), objetivo = ref(0), enviando = ref(false)
const ideas = ['Fondo de emergencia', 'Vacaciones', 'Moto', 'Estudio', 'Regalos de diciembre']
const listo = computed(() => nombre.value.trim() && objetivo.value > 0)
async function guardar() {
  if (!listo.value || enviando.value) return
  enviando.value = true
  try {
    await api.post('/metas', { nombre: nombre.value, objetivo: objetivo.value })
    await datosCambiaron(`Meta “${nombre.value.trim()}” creada. Ya puedes empezar a guardar.`)
    emit('listo')
  } catch (e) { avisar(e.message, 'error') } finally { enviando.value = false }
}
</script>

<template>
  <form class="grid gap-5" @submit.prevent="guardar">
    <div>
      <label class="label" for="m-nombre">¿Para qué quieres ahorrar?</label>
      <input id="m-nombre" v-model="nombre" class="input" maxlength="80" placeholder="Ej: Vacaciones" autocomplete="off" />
      <div class="mt-2 flex flex-wrap gap-1.5">
        <button v-for="i in ideas" :key="i" type="button" class="rounded-full border border-line px-3 py-1 text-xs font-semibold hover:bg-surface-2" @click="nombre = i">{{ i }}</button>
      </div>
    </div>
    <div>
      <label class="label" for="m-obj">¿Cuánto quieres reunir?</label>
      <MoneyInput id="m-obj" v-model="objetivo" grande />
    </div>
    <button class="btn btn-primary w-full py-3.5 text-base" :disabled="!listo || enviando">Crear meta</button>
  </form>
</template>
