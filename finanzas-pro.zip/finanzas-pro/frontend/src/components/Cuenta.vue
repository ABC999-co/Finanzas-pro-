<script setup>
// Menú de la cuenta: tema, datos de ejemplo, borrar datos y cerrar sesión
import { ref, onMounted, onBeforeUnmount } from 'vue'
import { Sun, Moon, Monitor, LogOut, Sparkles, ChevronUp } from 'lucide-vue-next'
import ConfirmButton from './ConfirmButton.vue'
import { estado, ponerTema, datosCambiaron, avisar } from '../lib/store.js'
import { api } from '../lib/api.js'
defineProps({ compacto: Boolean })
const abierto = ref(false), raiz = ref(null)
const cerrarFuera = (e) => { if (raiz.value && !raiz.value.contains(e.target)) abierto.value = false }
onMounted(() => document.addEventListener('click', cerrarFuera))
onBeforeUnmount(() => document.removeEventListener('click', cerrarFuera))
const inicial = () => (estado.usuario?.nombre || '?').trim().charAt(0).toUpperCase()

async function ejemplo() {
  try { await api.post('/demo'); await datosCambiaron('Datos de ejemplo cargados. Explora con calma.'); abierto.value = false }
  catch (e) { avisar(e.message, 'error') }
}
async function borrar() {
  try { await api.del('/datos'); await datosCambiaron('Tus datos fueron borrados. Empiezas de cero.'); abierto.value = false }
  catch (e) { avisar(e.message, 'error') }
}
async function salir() { await api.post('/auth/salir').catch(() => {}); estado.usuario = null }
const temas = [['sistema', 'Auto', Monitor], ['claro', 'Claro', Sun], ['oscuro', 'Oscuro', Moon]]
</script>

<template>
  <div ref="raiz" class="relative">
    <button v-if="compacto" class="grid size-9 place-items-center rounded-full bg-accent-soft font-bold" :aria-expanded="abierto" aria-label="Tu cuenta" @click="abierto = !abierto">{{ inicial() }}</button>
    <button v-else class="flex w-full items-center gap-3 rounded-xl p-2 text-left hover:bg-surface-2" :aria-expanded="abierto" @click="abierto = !abierto">
      <span class="grid size-9 shrink-0 place-items-center rounded-full bg-accent-soft font-bold">{{ inicial() }}</span>
      <span class="min-w-0 flex-1"><span class="block truncate text-sm font-bold">{{ estado.usuario?.nombre }}</span><span class="block truncate text-xs text-muted">{{ estado.usuario?.email }}</span></span>
      <ChevronUp :size="16" class="text-muted transition-transform" :class="abierto ? '' : 'rotate-180'" />
    </button>
    <Transition enter-from-class="opacity-0 translate-y-1" leave-to-class="opacity-0" enter-active-class="transition duration-150" leave-active-class="transition duration-100">
      <div v-if="abierto" class="absolute z-40 grid w-72 gap-3 rounded-2xl border border-line bg-surface p-3 shadow-card"
           :class="compacto ? 'right-0 top-12' : 'bottom-14 left-0'">
        <div v-if="compacto" class="px-1"><p class="font-bold">{{ estado.usuario?.nombre }}</p><p class="text-xs text-muted">{{ estado.usuario?.email }}</p></div>
        <div>
          <p class="eyebrow mb-1.5 px-1">Apariencia</p>
          <div class="grid grid-cols-3 gap-1 rounded-xl bg-surface-2 p-1">
            <button v-for="[v, t, I] in temas" :key="v" class="flex items-center justify-center gap-1 rounded-lg py-1.5 text-xs font-bold"
                    :class="estado.tema === v ? 'bg-surface shadow-card' : 'text-muted'" :aria-pressed="estado.tema === v" @click="ponerTema(v)">
              <component :is="I" :size="14" /> {{ t }}
            </button>
          </div>
        </div>
        <div class="grid gap-1.5 border-t border-line pt-3">
          <button class="btn btn-sm justify-start" @click="ejemplo"><Sparkles :size="15" /> Cargar datos de ejemplo</button>
          <ConfirmButton class="justify-start" texto="Borrar todos mis datos" confirmar="¿Seguro? Se borra todo" @confirmado="borrar" />
          <button class="btn btn-sm justify-start" @click="salir"><LogOut :size="15" /> Cerrar sesión</button>
        </div>
      </div>
    </Transition>
  </div>
</template>
