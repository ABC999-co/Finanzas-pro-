<script setup>
import { computed } from 'vue'
import { money } from '../lib/format.js'
import { icono } from '../lib/icons.js'
const props = defineProps({ items: Array, total: Number }) // [{ categoria, icono, clase, total }]
const max = computed(() => Math.max(1, ...props.items.map((i) => i.total)))
</script>

<template>
  <ul class="grid gap-3.5" v-auto-animate>
    <li v-for="c in items" :key="c.categoria" class="grid grid-cols-[2rem_minmax(0,1fr)] items-center gap-3" :title="`${c.categoria}: ${money(c.total)}`">
      <span class="grid size-8 place-items-center rounded-xl bg-gas-soft text-gas"><component :is="icono(c.icono)" :size="16" /></span>
      <div class="min-w-0">
        <div class="mb-1 flex justify-between gap-2 text-sm">
          <span class="truncate font-semibold">{{ c.categoria }} <span v-if="c.clase === 'fijo'" class="font-normal text-muted">· fijo</span></span>
          <span class="shrink-0 font-semibold">{{ money(c.total) }} <span class="font-normal text-muted">{{ Math.round(c.total / Math.max(total, 1) * 100) }}%</span></span>
        </div>
        <div class="h-2 overflow-hidden rounded-full bg-surface-2">
          <div class="h-full rounded-full bg-gas transition-[width] duration-500" :style="{ width: `${(c.total / max) * 100}%` }"></div>
        </div>
      </div>
    </li>
  </ul>
</template>
