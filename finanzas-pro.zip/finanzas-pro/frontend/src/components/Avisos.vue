<script setup>
import { estado } from '../lib/store.js'
import { CircleCheck, CircleAlert } from 'lucide-vue-next'
</script>

<template>
  <div class="pointer-events-none fixed inset-x-0 z-[60] flex flex-col items-center gap-2 px-4 bottom-[calc(96px+env(safe-area-inset-bottom))] md:bottom-6"
       aria-live="polite" v-auto-animate>
    <div v-for="a in estado.avisos" :key="a.id" role="status"
         class="pointer-events-auto flex max-w-md items-start gap-2.5 rounded-2xl px-4 py-3 font-semibold shadow-card"
         :class="a.tipo === 'error' ? 'bg-danger text-white' : 'bg-fg text-bg'">
      <component :is="a.tipo === 'error' ? CircleAlert : CircleCheck" :size="20" class="mt-0.5 shrink-0" />
      <span>{{ a.texto }}</span>
    </div>
  </div>
</template>
