<script setup>
import { computed, ref } from 'vue'
import MoneyInput from './MoneyInput.vue'
import SaldoVivo from './SaldoVivo.vue'
import { estado, datosCambiaron, avisar } from '../lib/store.js'
import { api } from '../lib/api.js'
import { money } from '../lib/format.js'
const props = defineProps({ meta: Object, accion: { type: String, default: 'deposito' } })
const emit = defineEmits(['listo'])
const tipo = ref(props.accion), monto = ref(0), enviando = ref(false)
const tope = computed(() => (tipo.value === 'deposito' ? estado.saldo.disponible : props.meta.saldo))
const listo = computed(() => monto.value > 0 && monto.value <= tope.value)
const faltan = computed(() => Math.max(props.meta.objetivo - props.meta.saldo, 0))
async function guardar() {
  if (!listo.value || enviando.value) return
  enviando.value = true
  try {
    await api.post(`/metas/${props.meta.id}/movimientos`, { tipo: tipo.value, monto: monto.value })
    await datosCambiaron(tipo.value === 'deposito' ? `Guardaste ${money(monto.value)} en “${props.meta.nombre}”.` : `Retiraste ${money(monto.value)}. Ya está en tu disponible.`)
    emit('listo')
  } catch (e) { avisar(e.message, 'error') } finally { enviando.value = false }
}
</script>

<template>
  <form class="grid gap-5" @submit.prevent="guardar">
    <div class="grid grid-cols-2 gap-1 rounded-2xl bg-surface-2 p-1">
      <button v-for="t in [['deposito', 'Guardar'], ['retiro', 'Retirar']]" :key="t[0]" type="button"
              class="rounded-xl px-3 py-2 font-bold transition-colors" :class="tipo === t[0] ? 'bg-surface shadow-card' : 'text-muted'"
              :aria-pressed="tipo === t[0]" @click="tipo = t[0]">{{ t[1] }}</button>
    </div>
    <div>
      <label class="label" for="ah-monto">{{ tipo === 'deposito' ? '¿Cuánto vas a guardar?' : '¿Cuánto vas a retirar?' }}</label>
      <MoneyInput id="ah-monto" v-model="monto" grande />
      <SaldoVivo v-if="tipo === 'deposito'" :monto="monto" accion="guardar" />
      <SaldoVivo v-else :monto="monto" :limite="meta.saldo" :texto-limite="`Esta meta tiene ${money(meta.saldo)}.`" />
      <button v-if="tipo === 'deposito' && faltan > 0 && faltan <= estado.saldo.disponible" type="button"
              class="mt-2 text-sm font-semibold text-accent underline-offset-2 hover:underline" @click="monto = faltan">
        Completar la meta ({{ money(faltan) }})
      </button>
    </div>
    <button class="btn btn-primary w-full py-3.5 text-base" :disabled="!listo || enviando">
      {{ tipo === 'deposito' ? 'Guardar en la meta' : 'Retirar a mi disponible' }}
    </button>
  </form>
</template>
