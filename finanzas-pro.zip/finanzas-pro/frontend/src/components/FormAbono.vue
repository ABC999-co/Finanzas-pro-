<script setup>
import { computed, ref } from 'vue'
import MoneyInput from './MoneyInput.vue'
import SaldoVivo from './SaldoVivo.vue'
import { datosCambiaron, avisar } from '../lib/store.js'
import { api } from '../lib/api.js'
import { money, hoy } from '../lib/format.js'
const props = defineProps({ prestamo: Object })
const emit = defineEmits(['listo'])
const monto = ref(0), fecha = ref(hoy()), enviando = ref(false)
const listo = computed(() => monto.value > 0 && monto.value <= props.prestamo.pendiente)
async function guardar(valor = monto.value) {
  if (enviando.value) return
  enviando.value = true
  try {
    const r = await api.post(`/prestamos/${props.prestamo.id}/abonos`, { monto: valor, fecha: fecha.value })
    await datosCambiaron(r.pendiente <= 0 ? `${props.prestamo.persona} terminó de pagarte. 🎉` : `Abono de ${money(valor)} registrado. Volvió a tu disponible.`)
    emit('listo')
  } catch (e) { avisar(e.message, 'error') } finally { enviando.value = false }
}
</script>

<template>
  <form class="grid gap-5" @submit.prevent="listo && guardar()">
    <div>
      <label class="label" for="a-monto">¿Cuánto te pagó?</label>
      <MoneyInput id="a-monto" v-model="monto" grande />
      <SaldoVivo :monto="monto" :limite="prestamo.pendiente" :texto-limite="`${prestamo.persona} te debe ${money(prestamo.pendiente)}.`" />
    </div>
    <div><label class="label" for="a-fecha">Fecha</label><input id="a-fecha" v-model="fecha" type="date" :max="hoy()" class="input" /></div>
    <div class="grid gap-2 sm:grid-cols-2">
      <button type="button" class="btn" :disabled="enviando" @click="guardar(prestamo.pendiente)">Pagó todo ({{ money(prestamo.pendiente) }})</button>
      <button class="btn btn-primary" :disabled="!listo || enviando">Registrar abono</button>
    </div>
  </form>
</template>
