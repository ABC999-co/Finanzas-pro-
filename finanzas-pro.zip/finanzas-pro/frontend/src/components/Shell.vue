<script setup>
import { LayoutDashboard, ArrowDownLeft, ArrowUpRight, HandCoins, PiggyBank, Plus } from 'lucide-vue-next'
import HojaActiva from './HojaActiva.vue'
import Cuenta from './Cuenta.vue'
import { estado } from '../lib/store.js'
import { money } from '../lib/format.js'

const secciones = [
  { to: '/', nombre: 'Resumen', icono: LayoutDashboard, color: 'var(--accent)' },
  { to: '/ingresos', nombre: 'Ingresos', icono: ArrowDownLeft, color: 'var(--ing)' },
  { to: '/gastos', nombre: 'Gastos', icono: ArrowUpRight, color: 'var(--gas)' },
  { to: '/prestamos', nombre: 'Préstamos', icono: HandCoins, color: 'var(--pre)' },
  { to: '/ahorros', nombre: 'Ahorros', icono: PiggyBank, color: 'var(--aho)' },
]
const nuevo = () => (estado.hoja = { tipo: 'menu' })
</script>

<template>
  <div class="min-h-dvh md:grid md:grid-cols-[260px_minmax(0,1fr)]">
    <!-- Barra lateral (computador) -->
    <aside class="sticky top-0 hidden h-dvh flex-col gap-6 border-r border-line bg-surface px-4 py-6 md:flex">
      <RouterLink to="/" class="flex items-center gap-2.5 px-2 font-display text-lg font-bold">
        <span class="grid size-9 place-items-center rounded-xl bg-accent text-accent-ink">$</span> Mis Finanzas
      </RouterLink>
      <button class="btn btn-primary w-full" @click="nuevo"><Plus :size="18" /> Nuevo registro</button>
      <nav class="grid gap-1" aria-label="Secciones">
        <RouterLink v-for="s in secciones" :key="s.to" :to="s.to"
          class="group flex items-center gap-3 rounded-xl px-3 py-2.5 font-semibold text-muted transition-colors hover:bg-surface-2 hover:text-fg"
          exact-active-class="!bg-accent-soft !text-fg">
          <component :is="s.icono" :size="19" :style="{ color: s.color }" /> {{ s.nombre }}
        </RouterLink>
      </nav>
      <div class="mt-auto grid gap-3">
        <div class="rounded-2xl bg-surface-2 p-4">
          <p class="eyebrow">Disponible</p>
          <p class="font-display text-2xl font-bold" :class="estado.saldo.disponible < 0 ? 'text-danger' : ''">{{ money(estado.saldo.disponible) }}</p>
          <p class="mt-1 text-xs text-muted">Lo que puedes gastar, prestar o ahorrar.</p>
        </div>
        <Cuenta />
      </div>
    </aside>

    <div class="min-w-0">
      <!-- Encabezado (celular) -->
      <header class="sticky z-30 flex items-center justify-between gap-3 border-b border-line bg-surface/90 py-2.5 backdrop-blur md:hidden
                     top-[env(safe-area-inset-top)] pl-[max(16px,env(safe-area-inset-left))] pr-[max(16px,env(safe-area-inset-right))]">
        <RouterLink to="/" class="flex items-center gap-2 font-display font-bold">
          <span class="grid size-8 place-items-center rounded-lg bg-accent text-sm text-accent-ink">$</span>
        </RouterLink>
        <div class="flex flex-1 flex-col items-center leading-tight">
          <span class="eyebrow !text-[.65rem]">Disponible</span>
          <span class="font-display font-bold" :class="estado.saldo.disponible < 0 ? 'text-danger' : ''">{{ money(estado.saldo.disponible) }}</span>
        </div>
        <Cuenta compacto />
      </header>

      <main class="mx-auto w-full max-w-6xl pb-32 pt-5 md:pb-12 md:pt-8 pl-[max(16px,env(safe-area-inset-left))] pr-[max(16px,env(safe-area-inset-right))] md:px-8">
        <slot />
      </main>
    </div>

    <!-- Botón flotante + barra inferior (celular) -->
    <button class="fixed right-[max(16px,env(safe-area-inset-right))] z-30 grid size-14 place-items-center rounded-2xl bg-accent text-accent-ink shadow-card transition-transform active:scale-95 md:hidden
                   bottom-[calc(76px+env(safe-area-inset-bottom))]" aria-label="Nuevo registro" @click="nuevo">
      <Plus :size="26" />
    </button>
    <nav class="fixed inset-x-0 bottom-0 z-30 grid grid-cols-5 border-t border-line bg-surface/95 px-1 pt-1.5 backdrop-blur md:hidden
                pb-[max(6px,env(safe-area-inset-bottom))]" aria-label="Secciones">
      <RouterLink v-for="s in secciones" :key="s.to" :to="s.to"
        class="flex flex-col items-center gap-0.5 rounded-xl py-1.5 text-[.7rem] font-bold text-muted transition-colors"
        exact-active-class="!text-fg [&_.pastilla]:!bg-accent-soft">
        <span class="pastilla grid h-7 w-12 place-items-center rounded-full transition-colors"><component :is="s.icono" :size="19" :style="{ color: s.color }" /></span>
        {{ s.nombre }}
      </RouterLink>
    </nav>

    <HojaActiva />
  </div>
</template>
