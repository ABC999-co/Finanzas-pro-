<script setup>
// Campo de dinero: muestra separadores de miles mientras escribes (1.500.000)
import { computed } from 'vue'
const model = defineModel({ type: Number, default: 0 })
const props = defineProps({ id: String, grande: Boolean, placeholder: { type: String, default: '0' } })
const texto = computed(() => (model.value ? new Intl.NumberFormat('es-CO').format(model.value) : ''))
function escribir(e) {
  const digitos = e.target.value.replace(/\D/g, '').slice(0, 12)
  model.value = digitos ? Number(digitos) : 0
  e.target.value = texto.value
}
</script>

<template>
  <div class="relative">
    <span class="pointer-events-none absolute left-4 top-1/2 -translate-y-1/2 font-display font-semibold text-muted"
          :class="grande ? 'text-2xl' : ''">$</span>
    <input :id="id" class="input font-display font-semibold" :class="grande ? 'py-4 pl-10 text-3xl' : 'pl-8'"
           type="text" inputmode="numeric" autocomplete="off" :placeholder="placeholder" :value="texto" @input="escribir" />
  </div>
</template>
