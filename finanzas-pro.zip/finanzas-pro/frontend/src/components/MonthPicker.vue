<script setup>
import { ChevronLeft, ChevronRight } from 'lucide-vue-next'
import { nombreMes, moverMes, mesActual } from '../lib/format.js'
const mes = defineModel({ type: String })
</script>

<template>
  <div class="inline-flex items-center gap-1 rounded-2xl border border-line bg-surface p-1">
    <button class="rounded-xl p-2 text-muted hover:bg-surface-2" @click="mes = moverMes(mes, -1)" aria-label="Mes anterior"><ChevronLeft :size="18" /></button>
    <span class="min-w-[9.5rem] text-center text-sm font-bold">{{ nombreMes(mes) }}</span>
    <button class="rounded-xl p-2 text-muted hover:bg-surface-2 disabled:opacity-30" :disabled="mes >= mesActual()"
            @click="mes = moverMes(mes, 1)" aria-label="Mes siguiente"><ChevronRight :size="18" /></button>
  </div>
</template>
