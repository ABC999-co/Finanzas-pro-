<script setup>
// Muestra el formulario que esté abierto. Nunca hay dos hojas una encima de otra.
import { computed } from 'vue'
import { ArrowDownLeft, ArrowUpRight, HandCoins, PiggyBank, ChevronRight } from 'lucide-vue-next'
import Sheet from './Sheet.vue'
import FormMovimiento from './FormMovimiento.vue'
import FormPrestamo from './FormPrestamo.vue'
import FormAbono from './FormAbono.vue'
import FormMeta from './FormMeta.vue'
import FormAhorro from './FormAhorro.vue'
import { estado } from '../lib/store.js'
import { money } from '../lib/format.js'

const h = computed(() => estado.hoja)
const cerrar = () => (estado.hoja = null)
const abrir = (tipo) => (estado.hoja = { tipo })
const titulos = {
  menu: ['¿Qué quieres registrar?', null],
  ingreso: ['Nuevo ingreso', 'Dinero que entra'],
  gasto: ['Nuevo gasto', null],
  prestamo: ['Prestar dinero', 'Sale de tu disponible hasta que te paguen'],
  abono: ['Registrar pago', null],
  meta: ['Nueva meta de ahorro', null],
  ahorro: ['Mover dinero', null],
}
const titulo = computed(() => {
  const t = h.value?.tipo
  if (t === 'abono') return [`Pago de ${h.value.prestamo.persona}`, `Te debe ${money(h.value.prestamo.pendiente)}`]
  if (t === 'ahorro') return [h.value.meta.nombre, `Ahorrado: ${money(h.value.meta.saldo)} de ${money(h.value.meta.objetivo)}`]
  if (t === 'gasto') return ['Nuevo gasto', `Tienes ${money(estado.saldo.disponible)} disponibles`]
  return titulos[t] || ['', null]
})
const opciones = [
  { tipo: 'ingreso', titulo: 'Ingreso', texto: 'Salario, maraña, trabajo extra', icono: ArrowDownLeft, clase: 'bg-ing-soft text-ing' },
  { tipo: 'gasto', titulo: 'Gasto', texto: 'Arriendo, servicios, almuerzo', icono: ArrowUpRight, clase: 'bg-gas-soft text-gas' },
  { tipo: 'prestamo', titulo: 'Préstamo', texto: 'Le prestas dinero a alguien', icono: HandCoins, clase: 'bg-pre-soft text-pre' },
  { tipo: 'meta', titulo: 'Meta de ahorro', texto: 'Separa dinero para algo', icono: PiggyBank, clase: 'bg-aho-soft text-aho' },
]
</script>

<template>
  <Sheet v-if="h" :key="h.tipo" :titulo="titulo[0]" :subtitulo="titulo[1]" @cerrar="cerrar">
    <div v-if="h.tipo === 'menu'" class="grid gap-2">
      <button v-for="o in opciones" :key="o.tipo" class="flex items-center gap-3 rounded-2xl border border-line p-3 text-left transition-colors hover:bg-surface-2" @click="abrir(o.tipo)">
        <span class="grid size-11 place-items-center rounded-xl" :class="o.clase"><component :is="o.icono" :size="20" /></span>
        <span class="flex-1"><span class="block font-bold">{{ o.titulo }}</span><span class="block text-sm text-muted">{{ o.texto }}</span></span>
        <ChevronRight :size="18" class="text-muted" />
      </button>
    </div>
    <FormMovimiento v-else-if="h.tipo === 'ingreso' || h.tipo === 'gasto'" :tipo="h.tipo" @listo="cerrar" />
    <FormPrestamo v-else-if="h.tipo === 'prestamo'" @listo="cerrar" />
    <FormAbono v-else-if="h.tipo === 'abono'" :prestamo="h.prestamo" @listo="cerrar" />
    <FormMeta v-else-if="h.tipo === 'meta'" @listo="cerrar" />
    <FormAhorro v-else-if="h.tipo === 'ahorro'" :meta="h.meta" :accion="h.accion" @listo="cerrar" />
  </Sheet>
</template>
