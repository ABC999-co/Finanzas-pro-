<script setup>
// Hoja de formulario: sube desde abajo en celular, ventana centrada en computador.
import { onMounted, onBeforeUnmount, ref, nextTick } from 'vue'
import { X } from 'lucide-vue-next'
const props = defineProps({ titulo: String, subtitulo: String })
const emit = defineEmits(['cerrar'])
const panel = ref(null)
const onKey = (e) => { if (e.key === 'Escape') emit('cerrar') }
onMounted(async () => {
  document.addEventListener('keydown', onKey)
  document.body.style.overflow = 'hidden'
  await nextTick()
  // En computador enfoca el primer campo; en celular no, para no tapar la hoja con el teclado
  if (window.matchMedia('(min-width: 768px)').matches) panel.value?.querySelector('input, select, button:not([data-cerrar])')?.focus()
})
onBeforeUnmount(() => { document.removeEventListener('keydown', onKey); document.body.style.overflow = '' })
</script>

<template>
  <div class="fixed inset-0 z-50 flex items-end justify-center md:items-center md:p-6" role="dialog" aria-modal="true" :aria-label="titulo">
    <div class="velo absolute inset-0 bg-black/40 backdrop-blur-[2px]" @click="emit('cerrar')"></div>
    <div ref="panel" class="hoja relative flex w-full flex-col bg-surface shadow-card md:max-w-md md:rounded-3xl rounded-t-3xl border border-line
                max-h-[calc(100dvh-24px)] md:max-h-[calc(100dvh-48px)]">
      <div class="mx-auto mt-2.5 h-1.5 w-10 rounded-full bg-line md:hidden" aria-hidden="true"></div>
      <header class="flex items-start justify-between gap-4 px-5 pt-3 md:pt-5">
        <div>
          <h2 class="text-lg font-semibold">{{ titulo }}</h2>
          <p v-if="subtitulo" class="text-sm text-muted">{{ subtitulo }}</p>
        </div>
        <button data-cerrar class="rounded-full p-2 text-muted hover:bg-surface-2" @click="emit('cerrar')" aria-label="Cerrar"><X :size="20" /></button>
      </header>
      <div class="overflow-y-auto overscroll-contain px-5 pt-4" style="padding-bottom: max(20px, env(safe-area-inset-bottom))">
        <slot />
      </div>
    </div>
  </div>
</template>

<style scoped>
.velo { animation: aparecer .2s ease both; }
.hoja { animation: subir .28s cubic-bezier(.2, .8, .2, 1) both; }
@media (min-width: 768px) { .hoja { animation-name: acercar; } }
@keyframes aparecer { from { opacity: 0 } }
@keyframes subir { from { transform: translateY(100%) } }
@keyframes acercar { from { opacity: 0; transform: translateY(12px) scale(.98) } }
</style>
