<script setup>
import { computed, ref } from 'vue'
import MoneyInput from './MoneyInput.vue'
import SaldoVivo from './SaldoVivo.vue'
import { estado, datosCambiaron, avisar } from '../lib/store.js'
import { api } from '../lib/api.js'
import { money, hoy } from '../lib/format.js'
const emit = defineEmits(['listo'])
const persona = ref(''), monto = ref(0), fecha = ref(hoy()), nota = ref(''), enviando = ref(false)
const listo = computed(() => persona.value.trim() && monto.value > 0 && monto.value <= estado.saldo.disponible)
async function guardar() {
  if (!listo.value || enviando.value) return
  enviando.value = true
  try {
    await api.post('/prestamos', { persona: persona.value, monto: monto.value, fecha: fecha.value, nota: nota.value })
    await datosCambiaron(`Le prestaste ${money(monto.value)} a ${persona.value.trim()}.`)
    emit('listo')
  } catch (e) { avisar(e.message, 'error') } finally { enviando.value = false }
}
</script>

<template>
  <form class="grid gap-5" @submit.prevent="guardar">
    <div>
      <label class="label" for="p-monto">¿Cuánto vas a prestar?</label>
      <MoneyInput id="p-monto" v-model="monto" grande />
      <SaldoVivo :monto="monto" accion="prestar" />
    </div>
    <div>
      <label class="label" for="p-persona">¿A quién?</label>
      <input id="p-persona" v-model="persona" class="input" maxlength="80" placeholder="Nombre de la persona" autocomplete="off" />
    </div>
    <div class="grid gap-4 sm:grid-cols-2">
      <div><label class="label" for="p-fecha">Fecha</label><input id="p-fecha" v-model="fecha" type="date" :max="hoy()" class="input" /></div>
      <div><label class="label" for="p-nota">Nota <span class="font-normal text-muted">(opcional)</span></label>
        <input id="p-nota" v-model="nota" class="input" maxlength="120" placeholder="Ej: paga el 30" /></div>
    </div>
    <button class="btn btn-primary w-full py-3.5 text-base" :disabled="!listo || enviando">{{ enviando ? 'Guardando…' : 'Registrar préstamo' }}</button>
  </form>
</template>
