<script setup>
import { computed, ref, watch } from 'vue'
import MoneyInput from './MoneyInput.vue'
import SaldoVivo from './SaldoVivo.vue'
import { estado, datosCambiaron, avisar } from '../lib/store.js'
import { api } from '../lib/api.js'
import { money, hoy, ayer } from '../lib/format.js'
import { icono } from '../lib/icons.js'

const props = defineProps({ tipo: { type: String, required: true } }) // 'ingreso' | 'gasto'
const emit = defineEmits(['listo'])
const esGasto = computed(() => props.tipo === 'gasto')
const monto = ref(0)
const clase = ref('fijo')
const categoriaId = ref(null)
const descripcion = ref('')
const fecha = ref(hoy())
const enviando = ref(false)

const categorias = computed(() => estado.categorias.filter((c) => c.movimiento === props.tipo && c.clase === clase.value))
watch(categorias, (cs) => { if (!cs.some((c) => c.id === categoriaId.value)) categoriaId.value = cs[0]?.id ?? null }, { immediate: true })
const excede = computed(() => esGasto.value && monto.value > estado.saldo.disponible)
const listo = computed(() => monto.value > 0 && categoriaId.value && fecha.value && !excede.value)

async function guardar() {
  if (!listo.value || enviando.value) return
  enviando.value = true
  try {
    await api.post(esGasto.value ? '/gastos' : '/ingresos', { monto: monto.value, categoria_id: categoriaId.value, descripcion: descripcion.value, fecha: fecha.value })
    await datosCambiaron(`${esGasto.value ? 'Gasto' : 'Ingreso'} de ${money(monto.value)} registrado.`)
    emit('listo')
  } catch (e) { avisar(e.message, 'error') } finally { enviando.value = false }
}
</script>

<template>
  <form class="grid gap-5" @submit.prevent="guardar">
    <div>
      <label class="label" :for="`monto-${tipo}`">¿Cuánto?</label>
      <MoneyInput :id="`monto-${tipo}`" v-model="monto" grande />
      <SaldoVivo v-if="esGasto" :monto="monto" accion="gastar" />
    </div>

    <fieldset>
      <legend class="label">¿Es {{ esGasto ? 'un gasto' : 'un ingreso' }} fijo o variable?</legend>
      <div class="grid grid-cols-2 gap-1 rounded-2xl bg-surface-2 p-1">
        <label v-for="c in ['fijo', 'variable']" :key="c"
               class="relative cursor-pointer rounded-xl px-3 py-2 text-center transition-colors"
               :class="clase === c ? 'bg-surface shadow-card' : 'text-muted'">
          <input v-model="clase" type="radio" :value="c" class="peer absolute opacity-0" />
          <span class="block font-bold capitalize">{{ c }}</span>
          <span class="block text-xs text-muted">{{ c === 'fijo' ? 'Se repite cada mes' : 'Cambia o es ocasional' }}</span>
        </label>
      </div>
    </fieldset>

    <fieldset>
      <legend class="label">Categoría</legend>
      <div class="grid grid-cols-2 gap-2 sm:grid-cols-3" v-auto-animate>
        <label v-for="c in categorias" :key="c.id"
               class="flex cursor-pointer items-center gap-2 rounded-xl border px-2.5 py-2 text-sm font-semibold transition-colors has-[:focus-visible]:ring-2 has-[:focus-visible]:ring-accent"
               :class="categoriaId === c.id ? 'border-accent bg-accent-soft' : 'border-line hover:bg-surface-2'">
          <input v-model="categoriaId" type="radio" :value="c.id" class="absolute opacity-0" />
          <component :is="icono(c.icono)" :size="16" class="shrink-0" :class="esGasto ? 'text-gas' : 'text-ing'" />
          <span class="min-w-0 leading-tight">{{ c.nombre }}</span>
        </label>
      </div>
    </fieldset>

    <div class="grid gap-4 sm:grid-cols-2">
      <div>
        <label class="label" :for="`desc-${tipo}`">Nota <span class="font-normal text-muted">(opcional)</span></label>
        <input :id="`desc-${tipo}`" v-model="descripcion" class="input" maxlength="120" :placeholder="esGasto ? 'Ej: recibo de la luz' : 'Ej: quincena'" />
      </div>
      <div>
        <label class="label" :for="`fecha-${tipo}`">Fecha</label>
        <div class="flex gap-1.5">
          <button type="button" class="btn btn-sm" :class="fecha === hoy() ? '!border-accent !bg-accent-soft' : ''" @click="fecha = hoy()">Hoy</button>
          <button type="button" class="btn btn-sm" :class="fecha === ayer() ? '!border-accent !bg-accent-soft' : ''" @click="fecha = ayer()">Ayer</button>
          <input :id="`fecha-${tipo}`" v-model="fecha" type="date" :max="hoy()" class="input !py-1.5 min-w-0" />
        </div>
      </div>
    </div>

    <button class="btn btn-primary w-full py-3.5 text-base" :disabled="!listo || enviando">
      {{ enviando ? 'Guardando…' : `Registrar ${esGasto ? 'gasto' : 'ingreso'}${monto ? ' de ' + money(monto) : ''}` }}
    </button>
  </form>
</template>
