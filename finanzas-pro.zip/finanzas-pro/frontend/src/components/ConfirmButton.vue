<script setup>
// Botón de dos pasos para acciones que no se pueden deshacer
import { ref, onBeforeUnmount } from 'vue'
import { Trash2 } from 'lucide-vue-next'
const props = defineProps({ texto: { type: String, default: 'Eliminar' }, confirmar: { type: String, default: '¿Seguro? Toca otra vez' }, compacto: Boolean })
const emit = defineEmits(['confirmado'])
const armado = ref(false)
let t
function tocar() {
  if (armado.value) { armado.value = false; clearTimeout(t); emit('confirmado'); return }
  armado.value = true
  t = setTimeout(() => (armado.value = false), 3500)
}
onBeforeUnmount(() => clearTimeout(t))
</script>

<template>
  <button class="btn btn-sm" :class="armado ? '!bg-danger !border-danger !text-white' : 'text-danger'" @click="tocar">
    <Trash2 :size="15" /> <span v-if="!compacto || armado">{{ armado ? confirmar : texto }}</span><span v-else class="sr-only">{{ texto }}</span>
  </button>
</template>
