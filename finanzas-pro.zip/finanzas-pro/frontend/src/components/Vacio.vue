<script setup>
defineProps({ icono: Object, titulo: String, texto: String })
</script>

<template>
  <div class="flex flex-col items-center gap-2 px-6 py-10 text-center">
    <div class="mb-1 grid size-12 place-items-center rounded-2xl bg-surface-2 text-muted"><component :is="icono" :size="22" /></div>
    <p class="font-bold">{{ titulo }}</p>
    <p class="max-w-xs text-sm text-muted">{{ texto }}</p>
    <div class="mt-2"><slot /></div>
  </div>
</template>
