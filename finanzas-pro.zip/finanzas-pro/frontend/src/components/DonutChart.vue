<script setup>
// Dona: ¿a dónde se fue lo que has recibido? Al pasar el cursor/tocar un segmento, el centro lo describe.
import { computed, ref } from 'vue'
import { money } from '../lib/format.js'
const props = defineProps({ partes: Array, total: Number }) // partes: [{ nombre, valor, color }]
const activo = ref(null)
const R = 70, C = 2 * Math.PI * R, GAP = 2.5
const segmentos = computed(() => {
  const base = Math.max(props.total, 1)
  let acum = 0
  return props.partes.map((p) => {
    const frac = Math.max(p.valor, 0) / base
    const largo = Math.max(frac * C - GAP, 0)
    const s = { ...p, frac, dash: `${largo} ${C - largo}`, offset: -acum }
    acum += frac * C
    return s
  })
})
const centro = computed(() => activo.value ?? segmentos.value[segmentos.value.length - 1])
const pct = (f) => `${Math.round(f * 100)}%`
</script>

<template>
  <div class="flex flex-col items-center gap-5 sm:flex-row sm:items-center">
    <div class="relative size-44 shrink-0">
      <svg viewBox="0 0 180 180" class="size-full -rotate-90" role="img" :aria-label="`Distribución de ${money(total)}`">
        <circle cx="90" cy="90" :r="R" fill="none" stroke="var(--surface-2)" stroke-width="22" />
        <circle v-for="s in segmentos" :key="s.nombre" cx="90" cy="90" :r="R" fill="none" :stroke="s.color"
                :stroke-width="activo?.nombre === s.nombre ? 26 : 22" :stroke-dasharray="s.dash" :stroke-dashoffset="s.offset"
                class="cursor-pointer transition-[stroke-width,opacity] duration-200"
                :opacity="activo && activo.nombre !== s.nombre ? .35 : 1"
                @mouseenter="activo = s" @mouseleave="activo = null" @click="activo = activo?.nombre === s.nombre ? null : s" />
      </svg>
      <div class="pointer-events-none absolute inset-0 flex flex-col items-center justify-center text-center">
        <span class="eyebrow">{{ centro?.nombre }}</span>
        <span class="font-display text-xl font-bold">{{ pct(centro?.frac || 0) }}</span>
        <span class="text-xs text-muted">{{ money(centro?.valor) }}</span>
      </div>
    </div>
    <ul class="grid w-full gap-1.5 text-sm">
      <li v-for="s in segmentos" :key="s.nombre"
          class="flex items-center justify-between gap-3 rounded-xl px-2.5 py-1.5 transition-colors"
          :class="activo?.nombre === s.nombre ? 'bg-surface-2' : ''" @mouseenter="activo = s" @mouseleave="activo = null">
        <span class="flex items-center gap-2"><i class="size-2.5 rounded-[3px]" :style="{ background: s.color }"></i>{{ s.nombre }}</span>
        <span class="font-semibold">{{ money(s.valor) }} <span class="font-normal text-muted">· {{ pct(s.frac) }}</span></span>
      </li>
    </ul>
  </div>
</template>
