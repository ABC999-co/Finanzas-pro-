<script setup>
// Mensaje en vivo: cuánto te quedará, o cuánto te falta. Evita tener que hacer cuentas mentales.
import { computed } from 'vue'
import { estado } from '../lib/store.js'
import { money } from '../lib/format.js'
import { CircleAlert, CircleCheck, Wallet } from 'lucide-vue-next'
const props = defineProps({ monto: Number, accion: String, limite: Number, textoLimite: String })
const tope = computed(() => props.limite ?? estado.saldo.disponible)
const estadoMsg = computed(() => {
  if (!props.monto) return { icono: Wallet, clase: 'text-muted', texto: props.textoLimite ?? `Puedes ${props.accion} hasta ${money(tope.value)}.` }
  if (props.monto > tope.value) return { icono: CircleAlert, clase: 'text-danger font-semibold', texto: `Te faltan ${money(props.monto - tope.value)}. Tienes ${money(tope.value)}.` }
  return { icono: CircleCheck, clase: 'text-ok', texto: props.limite != null ? `Quedará en ${money(tope.value - props.monto)}.` : `Te quedarán ${money(tope.value - props.monto)} disponibles.` }
})
</script>

<template>
  <p class="mt-2 flex items-center gap-1.5 text-sm" :class="estadoMsg.clase" aria-live="polite">
    <component :is="estadoMsg.icono" :size="16" class="shrink-0" /> {{ estadoMsg.texto }}
  </p>
</template>
