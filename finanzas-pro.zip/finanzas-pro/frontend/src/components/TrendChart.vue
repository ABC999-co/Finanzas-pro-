<script setup>
// Barras agrupadas: ingresos vs gastos de los últimos 6 meses, con información al pasar el cursor.
import { computed, ref } from 'vue'
import { money, compact, nombreMes } from '../lib/format.js'
const props = defineProps({ datos: Array }) // [{ mes, ingresos, gastos }]
const W = 560, H = 220, L = 44, B = 26, T = 12
const hover = ref(null)
// Escala con números redondos: pasos de 1, 2 o 5 (× 10ⁿ), máximo 4 divisiones
const escala = computed(() => {
  const m = Math.max(1, ...props.datos.flatMap((d) => [d.ingresos, d.gastos]))
  const bruto = m / 4, p = 10 ** Math.floor(Math.log10(bruto))
  const paso = [1, 2, 2.5, 5, 10].map((k) => k * p).find((s) => s >= bruto)
  return { paso, max: Math.ceil(m / paso) * paso }
})
const max = computed(() => escala.value.max)
const y = (v) => T + (H - T - B) * (1 - v / max.value)
const ticks = computed(() => Array.from({ length: Math.round(max.value / escala.value.paso) + 1 }, (_, i) => i * escala.value.paso))
const ancho = computed(() => (W - L) / props.datos.length)
const barra = computed(() => Math.min(22, ancho.value * 0.28))
function rect(x, v, w) { // barra con punta redondeada de 4px anclada a la base
  const top = y(v), base = y(0), r = Math.min(4, (base - top) / 2, w / 2)
  if (base - top < .5) return ''
  return `M${x},${base} V${top + r} Q${x},${top} ${x + r},${top} H${x + w - r} Q${x + w},${top} ${x + w},${top + r} V${base} Z`
}
</script>

<template>
  <div>
    <div class="mb-3 flex flex-wrap gap-4 text-sm">
      <span class="flex items-center gap-2"><i class="size-2.5 rounded-[3px] bg-ing"></i>Ingresos</span>
      <span class="flex items-center gap-2"><i class="size-2.5 rounded-[3px] bg-gas"></i>Gastos</span>
    </div>
    <div class="relative">
      <svg :viewBox="`0 0 ${W} ${H}`" class="w-full overflow-visible" role="img" aria-label="Ingresos y gastos de los últimos 6 meses">
        <g v-for="t in ticks" :key="t">
          <line :x1="L" :x2="W" :y1="y(t)" :y2="y(t)" stroke="var(--line)" :stroke-dasharray="t ? '3 4' : ''" />
          <text :x="L - 8" :y="y(t) + 4" text-anchor="end" font-size="11" fill="var(--muted)">{{ compact(t) }}</text>
        </g>
        <g v-for="(d, i) in datos" :key="d.mes" @mouseenter="hover = i" @mouseleave="hover = null" @click="hover = hover === i ? null : i">
          <rect :x="L + i * ancho" :y="T" :width="ancho" :height="H - T - B" :fill="hover === i ? 'var(--surface-2)' : 'transparent'" rx="8" class="cursor-pointer" />
          <path :d="rect(L + i * ancho + ancho / 2 - barra - 1, d.ingresos, barra)" fill="var(--ing)" />
          <path :d="rect(L + i * ancho + ancho / 2 + 1, d.gastos, barra)" fill="var(--gas)" />
          <text :x="L + i * ancho + ancho / 2" :y="H - 6" text-anchor="middle" font-size="12" fill="var(--muted)"
                :font-weight="i === datos.length - 1 ? 700 : 400">{{ nombreMes(d.mes, true) }}</text>
        </g>
      </svg>
      <div v-if="hover !== null" class="pointer-events-none absolute top-0 z-10 rounded-xl border border-line bg-surface px-3 py-2 text-sm shadow-card"
           :style="{ left: `clamp(0px, calc(${((L + hover * ancho + ancho / 2) / W) * 100}% - 80px), calc(100% - 170px))` }">
        <p class="font-bold">{{ nombreMes(datos[hover].mes) }}</p>
        <p class="flex justify-between gap-4"><span class="flex items-center gap-1.5"><i class="size-2 rounded-sm bg-ing"></i>Ingresos</span>{{ money(datos[hover].ingresos) }}</p>
        <p class="flex justify-between gap-4"><span class="flex items-center gap-1.5"><i class="size-2 rounded-sm bg-gas"></i>Gastos</span>{{ money(datos[hover].gastos) }}</p>
        <p class="mt-1 flex justify-between gap-4 border-t border-line pt-1 font-semibold"><span>Balance</span>{{ money(datos[hover].ingresos - datos[hover].gastos) }}</p>
      </div>
    </div>
  </div>
</template>
