import { createRouter, createWebHistory } from 'vue-router'
import { estado } from './lib/store.js'

export const router = createRouter({
  history: createWebHistory(),
  routes: [
    { path: '/entrar', component: () => import('./views/Entrar.vue'), meta: { publica: true } },
    { path: '/', component: () => import('./views/Resumen.vue'), meta: { titulo: 'Resumen' } },
    { path: '/ingresos', component: () => import('./views/Movimientos.vue'), props: { tipo: 'ingreso' }, meta: { titulo: 'Ingresos' } },
    { path: '/gastos', component: () => import('./views/Movimientos.vue'), props: { tipo: 'gasto' }, meta: { titulo: 'Gastos' } },
    { path: '/prestamos', component: () => import('./views/Prestamos.vue'), meta: { titulo: 'Préstamos' } },
    { path: '/ahorros', component: () => import('./views/Ahorros.vue'), meta: { titulo: 'Ahorros' } },
    { path: '/:pathMatch(.*)*', redirect: '/' },
  ],
  scrollBehavior: () => ({ top: 0 }),
})

router.beforeEach((to) => {
  if (estado.usuario === null && !to.meta.publica) return '/entrar'
  if (estado.usuario && to.meta.publica) return '/'
})
router.afterEach((to) => { document.title = to.meta.titulo ? `${to.meta.titulo} · Mis Finanzas` : 'Mis Finanzas' })
