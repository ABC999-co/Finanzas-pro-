<script setup>
import { onMounted } from 'vue'
import { useRouter } from 'vue-router'
import { watch } from 'vue'
import Shell from './components/Shell.vue'
import Avisos from './components/Avisos.vue'
import { estado, iniciar } from './lib/store.js'
const router = useRouter()
onMounted(async () => {
  await iniciar()
  router.replace(estado.usuario ? (router.currentRoute.value.meta.publica ? '/' : router.currentRoute.value.fullPath) : '/entrar')
})
// Si la sesión se cierra o vence, volver a la entrada
watch(() => estado.usuario, (u) => { if (u === null) router.replace('/entrar') })
</script>

<template>
  <div v-if="estado.usuario === undefined" class="grid min-h-dvh place-items-center">
    <div class="size-10 animate-spin rounded-full border-4 border-accent-soft border-t-accent" aria-label="Cargando"></div>
  </div>
  <RouterView v-else-if="!estado.usuario" />
  <Shell v-else>
    <RouterView v-slot="{ Component, route }">
      <Transition name="page" mode="out-in"><component :is="Component" :key="route.fullPath" /></Transition>
    </RouterView>
  </Shell>
  <Avisos />
</template>
