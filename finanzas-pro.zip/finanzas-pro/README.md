<div align="center">

# 💰 Mis Finanzas

**Aplicación web responsive para administrar tus finanzas personales.**
Ingresos, gastos, préstamos y ahorros, todos conectados a un solo número: tu **dinero disponible**.

![Vue](https://img.shields.io/badge/Vue-3.5-42b883?logo=vuedotjs&logoColor=white)
![Vite](https://img.shields.io/badge/Vite-8-646cff?logo=vite&logoColor=white)
![Tailwind](https://img.shields.io/badge/Tailwind_CSS-4-38bdf8?logo=tailwindcss&logoColor=white)
![PHP](https://img.shields.io/badge/PHP-8.1+-777bb4?logo=php&logoColor=white)
![Slim](https://img.shields.io/badge/Slim-4-74a045)
![MySQL](https://img.shields.io/badge/MySQL-MariaDB-4479a1?logo=mysql&logoColor=white)
![SQLite](https://img.shields.io/badge/SQLite-003b57?logo=sqlite&logoColor=white)

</div>

---

## 📑 Tabla de contenido

1. [¿Qué es Mis Finanzas?](#1-qué-es-mis-finanzas)
2. [La regla que conecta todo](#2-la-regla-que-conecta-todo)
3. [Funcionalidades](#3-funcionalidades)
4. [Capturas de pantalla](#4-capturas-de-pantalla)
5. [Tecnologías](#5-tecnologías)
6. [Arquitectura](#6-arquitectura)
7. [Estructura de carpetas](#7-estructura-de-carpetas)
8. [Base de datos](#8-base-de-datos)
9. [Reglas de negocio](#9-reglas-de-negocio)
10. [API REST](#10-api-rest)
11. [Seguridad](#11-seguridad)
12. [Diseño y experiencia de usuario](#12-diseño-y-experiencia-de-usuario)
13. [Instalación paso a paso en Windows](#13-instalación-paso-a-paso-en-windows)
14. [Instalación en Mac o Linux](#14-instalación-en-mac-o-linux)
15. [Usar MySQL en lugar de SQLite](#15-usar-mysql-en-lugar-de-sqlite)
16. [Guía de uso](#16-guía-de-uso)
17. [Desarrollo](#17-desarrollo)
18. [Despliegue con Apache](#18-despliegue-con-apache)
19. [Solución de problemas](#19-solución-de-problemas)
20. [Pruebas realizadas](#20-pruebas-realizadas)
21. [Posibles mejoras](#21-posibles-mejoras)

---

## 1. ¿Qué es Mis Finanzas?

Mis Finanzas es una aplicación web para llevar el control de tu dinero personal. Te permite:

- 📥 Registrar **ingresos fijos** (salario, pensión) y **variables** (marañas, trabajos extra, ventas).
- 📤 Registrar **gastos fijos** (arriendo, servicios públicos) y **variables** (almuerzos, gasolina, mercado).
- 🤝 **Prestar dinero** a otras personas y registrar los pagos que te hacen.
- 🐷 **Ahorrar** para metas concretas, como vacaciones o un fondo de emergencia.

**Lo más importante:** todos los módulos están conectados. **No puedes gastar, prestar ni ahorrar dinero que no tienes.**

Funciona en **cualquier pantalla**: celular, tablet y computador.

---

## 2. La regla que conecta todo

Todo el sistema gira alrededor de una fórmula:

```
DISPONIBLE = Ingresos − Gastos − (Préstamos − Abonos) − (Depósitos de ahorro − Retiros)
```

| Movimiento | Efecto en el disponible |
|---|---|
| Registrar un **ingreso** | ⬆️ Sube |
| Registrar un **gasto** | ⬇️ Baja |
| **Prestar** dinero | ⬇️ Baja |
| Recibir un **abono** de un préstamo | ⬆️ Sube |
| **Guardar** en una meta de ahorro | ⬇️ Baja |
| **Retirar** de una meta de ahorro | ⬆️ Sube |

```mermaid
flowchart LR
    I[📥 Ingresos<br/>fijos y variables] -->|suman| D((💰 DISPONIBLE))
    D -->|gastar| G[📤 Gastos<br/>fijos y variables]
    D -->|prestar| P[🤝 Préstamos]
    P -->|abonos| D
    D -->|guardar| A[🐷 Metas de ahorro]
    A -->|retirar| D
```

> 🔒 **La regla se valida en el servidor**, dentro de una transacción de base de datos. Aunque alguien modifique el navegador, el sistema nunca acepta un gasto, préstamo o ahorro mayor que el disponible.

---

## 3. Funcionalidades

### 👤 Cuentas de usuario
- Registro con nombre, correo y contraseña de mínimo 8 caracteres.
- Inicio y cierre de sesión.
- Cada usuario ve **solo sus propios datos**.

### 📥 Ingresos
- Tipo **fijo** o **variable**, cada uno con sus categorías:

| Fijos | Variables |
|---|---|
| Salario, Pensión, Arriendo recibido, Otro ingreso fijo | Trabajo extra, Maraña, Venta, Comisión, Regalo, Otro ingreso variable |

- Nota opcional y fecha, con accesos rápidos **Hoy** y **Ayer**.
- Lista agrupada por día, con filtro **Todos / Fijos / Variables** y navegación por mes.
- Totales del mes: fijos, variables y total.

### 📤 Gastos
- Tipo **fijo** o **variable**:

| Fijos | Variables |
|---|---|
| Arriendo, Servicios públicos, Internet y celular, Transporte mensual, Educación, Seguros, Cuota de crédito, Otro gasto fijo | Almuerzos, Gasolina, Mercado, Salidas, Salud, Ropa, Otro gasto variable |

- **Aviso en vivo mientras escribes el monto:**
  - ✅ *"Te quedarán $ 1.550.000 disponibles."*
  - ⚠️ *"Te faltan $ 500.000. Tienes $ 2.500.000."* (y el botón se desactiva)
- **Copiar gastos fijos del mes anterior** con un clic, sin duplicar los que ya existen.

### 🤝 Préstamos
- Prestas dinero de tu disponible a una persona, con nota opcional.
- Registras **abonos** (pagos parciales) o el **pago total** con un botón.
- Barra de progreso: cuánto te han pagado.
- Filtro **Pendientes / Pagados**.
- Totales: **Te deben**, **Prestado** y **Recuperado**.

### 🐷 Ahorros
- Creas **metas** con nombre y valor objetivo, con sugerencias como "Fondo de emergencia" o "Vacaciones".
- **Guardar:** mueve dinero del disponible a la meta.
- **Retirar:** devuelve dinero de la meta al disponible.
- Anillo de progreso, cuánto falta y mensaje de **¡Meta cumplida!**
- Botón **"Completar la meta"**, que calcula lo que falta.

### 📊 Resumen (panel principal)
- **Dinero disponible** en grande, con la fórmula desglosada.
- Indicadores del mes: ingresos, gastos, lo que te deben y lo ahorrado.
- **Gráfico de dona:** ¿a dónde se ha ido tu dinero?
- **Gráfico de barras:** ingresos y gastos de los últimos 6 meses (toca o pasa el cursor para ver el detalle).
- **Gastos del mes por categoría**, de mayor a menor.
- **Últimos movimientos** de todos los módulos.
- **Primeros pasos** para cuentas nuevas y **sugerencias** (por ejemplo, copiar los gastos fijos).

### ⚙️ Otros
- 🌗 Tema **claro**, **oscuro** o **automático**.
- ✨ **Datos de ejemplo** para mostrar la app en segundos.
- 🗑️ **Borrar todos mis datos**, con confirmación en dos pasos.

---

## 4. Capturas de pantalla

| Computador | Celular (modo oscuro) |
|---|---|
| ![Resumen](capturas/2-resumen-computador.png) | ![Gastos](capturas/4-gastos-celular-oscuro.png) |
| ![Ahorros](capturas/3-ahorros-computador.png) | ![Nuevo gasto](capturas/5-nuevo-gasto-celular.png) |

Pantalla de entrada:

![Entrar](capturas/1-entrar.png)

---

## 5. Tecnologías

### Frontend (lo que ves)
| Tecnología | Versión | Para qué se usa |
|---|---|---|
| **Vue** | 3.5 | Framework de la interfaz (Composition API con `<script setup>`) |
| **Vue Router** | 4 | Navegación entre pantallas sin recargar la página |
| **Vite** | 8 | Servidor de desarrollo y compilación (muy rápido) |
| **Tailwind CSS** | 4 | Estilos, diseño responsive y modo oscuro |
| **AutoAnimate** | 0.10 | Animaciones suaves en listas |
| **Lucide** | 1.0 | Íconos |
| **SVG propio** | — | Gráficos hechos a mano, sin librerías pesadas |

### Backend (el servidor)
| Tecnología | Versión | Para qué se usa |
|---|---|---|
| **PHP** | 8.1+ | Lenguaje del servidor |
| **Slim Framework** | 4.14 | Micro-framework para la API REST |
| **PDO** | — | Conexión segura a la base de datos |
| **MySQL / MariaDB** | 8.0+ / 10.3+ | Base de datos (opción 1) |
| **SQLite** | 3 | Base de datos en un archivo (opción 2, por defecto) |

### ¿Por qué estas tecnologías?
- **Vue 3** frente a React: código más fácil de leer y explicar, y un paquete más liviano.
- **Slim 4** frente a Laravel: moderno y estándar (PSR-7/PSR-15), pero mucho más liviano y fácil de entender.
- **Gráficos propios en SVG:** pesan casi nada y respetan el modo oscuro.
- **Resultado:** la app completa pesa unos **65 KB comprimidos** y carga muy rápido, incluso con datos móviles.

---

## 6. Arquitectura

### Vista general

```mermaid
flowchart TB
    subgraph Cliente["🖥️ Navegador (celular, tablet o PC)"]
        UI[Vue 3 · SPA<br/>Vistas + Componentes]
        ST[Estado compartido<br/>store.js]
        API_C[Cliente API<br/>api.js · fetch JSON]
        UI <--> ST
        UI --> API_C
    end

    subgraph Servidor["⚙️ Servidor PHP"]
        IDX[public/index.php<br/>Slim 4 · Rutas + Middleware]
        AUTH[Auth.php<br/>Registro / Login]
        FIN[Finanzas.php<br/>Reglas de negocio]
        VAL[Validar.php<br/>Validaciones]
        DB[Database.php<br/>PDO + Transacciones]
        IDX --> AUTH
        IDX --> FIN
        FIN --> VAL
        AUTH --> DB
        FIN --> DB
    end

    BD[(🗄️ MySQL o SQLite)]

    API_C -- "HTTP / JSON<br/>Cookie de sesión" --> IDX
    DB --> BD
```

### Patrón

Es una **SPA** (Single Page Application) que habla con una **API REST**:

1. **El frontend** (Vue) dibuja la interfaz y pide datos a la API con `fetch`.
2. **La API** (Slim) recibe la petición, revisa la sesión, aplica las reglas de negocio y responde en JSON.
3. **La base de datos** guarda todo. PDO permite usar **MySQL o SQLite** con el mismo código.

En producción, **un solo servidor PHP** entrega las dos cosas: la interfaz compilada (`backend/public/index.html` y `assets/`) y la API (`/api/*`). No hay problemas de CORS y la instalación es más simple.

### Capas del backend

| Capa | Archivo | Responsabilidad |
|---|---|---|
| **Entrada** | `public/index.php` | Rutas, sesión, middleware (CSRF y errores), respuestas JSON |
| **Autenticación** | `src/Auth.php` | Registro, login, logout y usuario actual |
| **Negocio** | `src/Finanzas.php` | Cálculo del disponible y todas las reglas |
| **Validación** | `src/Validar.php` | Montos, fechas, textos y mensajes en español |
| **Datos** | `src/Database.php` | Conexión, creación automática de tablas, transacciones con bloqueo |
| **Errores** | `src/ApiError.php` | Errores con mensaje para el usuario y código HTTP |

### Capas del frontend

| Capa | Ubicación | Responsabilidad |
|---|---|---|
| **Vistas** | `src/views/` | Pantallas completas (Resumen, Movimientos, Préstamos, Ahorros, Entrar) |
| **Componentes** | `src/components/` | Piezas reutilizables (formularios, gráficos, hoja inferior, avisos) |
| **Lógica compartida** | `src/lib/` | Cliente API, estado global, formatos de dinero y fecha, íconos |
| **Rutas** | `src/router.js` | Navegación y protección de rutas (sin sesión → `/entrar`) |
| **Estilos** | `src/style.css` | Tokens de diseño, temas claro y oscuro, Tailwind |

### Flujo de una operación: registrar un gasto

```mermaid
sequenceDiagram
    actor U as Usuario
    participant F as FormMovimiento.vue
    participant A as API (Slim)
    participant N as Finanzas.php
    participant B as Base de datos

    U->>F: Escribe $ 50.000
    F-->>U: "Te quedarán $ 1.500.000" (cálculo en vivo)
    U->>F: Toca "Registrar gasto"
    F->>A: POST /api/gastos {monto, categoria_id, fecha}
    A->>A: ¿Hay sesión? ¿Es JSON?
    A->>B: BEGIN + bloquear usuario
    A->>N: crearMovimiento('gastos')
    N->>N: Validar monto, fecha y categoría
    N->>B: Calcular disponible
    alt monto > disponible
        N-->>A: ApiError "No te alcanza…"
        A->>B: ROLLBACK
        A-->>F: 422 {error}
        F-->>U: Aviso rojo con el mensaje
    else monto ≤ disponible
        N->>B: INSERT INTO gastos
        A->>B: COMMIT
        A-->>F: 201 {id}
        F->>A: GET /api/saldo
        F-->>U: ✅ "Gasto registrado" + saldo actualizado
    end
```

### Concurrencia

Cada operación que mueve dinero corre dentro de `Database::transaction()`:
- **MySQL:** `SELECT … FOR UPDATE` bloquea la fila del usuario.
- **SQLite:** `BEGIN IMMEDIATE` bloquea la escritura.

Así, si alguien envía dos gastos al mismo tiempo, no pueden usar el mismo dinero dos veces.

---

## 7. Estructura de carpetas

```
finanzas-pro/
├── 📄 README.md                  ← este archivo
├── 📄 INSTALACION.md             guía de instalación detallada
├── ▶️ iniciar.bat                inicia la app en Windows (doble clic)
├── ▶️ iniciar.sh                 inicia la app en Mac/Linux
├── 📁 capturas/                  imágenes de la app
│
├── 📁 backend/                   SERVIDOR (PHP + Slim 4)
│   ├── config.php                ← aquí eliges SQLite o MySQL
│   ├── composer.json             dependencias de PHP
│   ├── 📁 public/                carpeta pública del servidor web
│   │   ├── index.php             punto de entrada: rutas de la API
│   │   ├── .htaccess             reglas para Apache
│   │   ├── index.html            interfaz compilada (generada)
│   │   └── 📁 assets/            JS y CSS compilados (generados)
│   ├── 📁 src/
│   │   ├── Finanzas.php          reglas de negocio
│   │   ├── Auth.php              autenticación
│   │   ├── Validar.php           validaciones
│   │   ├── Database.php          conexión y transacciones
│   │   └── ApiError.php          errores para el usuario
│   ├── 📁 database/
│   │   ├── schema.mysql.sql      tablas para MySQL
│   │   ├── schema.sqlite.sql     tablas para SQLite
│   │   └── categorias.sql        categorías iniciales
│   ├── 📁 storage/               aquí se crea finanzas.sqlite
│   └── 📁 vendor/                librerías de PHP (incluidas)
│
└── 📁 frontend/                  INTERFAZ (Vue 3 + Vite)
    ├── package.json              dependencias de Node
    ├── vite.config.js            configuración de compilación
    ├── index.html
    └── 📁 src/
        ├── main.js               arranque de la app
        ├── App.vue               componente raíz
        ├── router.js             rutas
        ├── style.css             tokens de diseño y temas
        ├── 📁 views/
        │   ├── Entrar.vue        iniciar sesión / crear cuenta
        │   ├── Resumen.vue       panel principal
        │   ├── Movimientos.vue   ingresos y gastos (misma vista)
        │   ├── Prestamos.vue
        │   └── Ahorros.vue
        ├── 📁 components/
        │   ├── Shell.vue         menú lateral, barra inferior y botón +
        │   ├── Sheet.vue         hoja inferior / ventana modal
        │   ├── HojaActiva.vue    decide qué formulario mostrar
        │   ├── FormMovimiento.vue, FormPrestamo.vue, FormAbono.vue,
        │   │   FormMeta.vue, FormAhorro.vue
        │   ├── MoneyInput.vue    campo de dinero con formato 1.500.000
        │   ├── SaldoVivo.vue     "te quedarán / te faltan" en vivo
        │   ├── DonutChart.vue, TrendChart.vue, CategoryBars.vue
        │   ├── MonthPicker.vue, ConfirmButton.vue, Avisos.vue,
        │   │   Cuenta.vue, Vacio.vue
        └── 📁 lib/
            ├── api.js            cliente HTTP
            ├── store.js          estado global (usuario, saldo, avisos, tema)
            ├── format.js         formatos de dinero (COP) y fechas
            └── icons.js          íconos de categorías
```

---

## 8. Base de datos

### Modelo entidad-relación

```mermaid
erDiagram
    USUARIOS ||--o{ INGRESOS : registra
    USUARIOS ||--o{ GASTOS : registra
    USUARIOS ||--o{ PRESTAMOS : hace
    USUARIOS ||--o{ METAS : crea
    CATEGORIAS ||--o{ INGRESOS : clasifica
    CATEGORIAS ||--o{ GASTOS : clasifica
    PRESTAMOS ||--o{ ABONOS : recibe
    METAS ||--o{ MOVIMIENTOS_AHORRO : tiene

    USUARIOS {
        int id PK
        varchar nombre
        varchar email UK
        varchar password_hash
        datetime creado_en
    }
    CATEGORIAS {
        int id PK
        varchar movimiento "ingreso | gasto"
        varchar clase "fijo | variable"
        varchar nombre
        varchar icono
    }
    INGRESOS {
        int id PK
        int usuario_id FK
        int categoria_id FK
        varchar descripcion
        decimal monto
        date fecha
    }
    GASTOS {
        int id PK
        int usuario_id FK
        int categoria_id FK
        varchar descripcion
        decimal monto
        date fecha
    }
    PRESTAMOS {
        int id PK
        int usuario_id FK
        varchar persona
        decimal monto
        date fecha
        varchar nota
    }
    ABONOS {
        int id PK
        int prestamo_id FK
        decimal monto
        date fecha
    }
    METAS {
        int id PK
        int usuario_id FK
        varchar nombre
        decimal objetivo
    }
    MOVIMIENTOS_AHORRO {
        int id PK
        int meta_id FK
        varchar tipo "deposito | retiro"
        decimal monto
        date fecha
    }
```

### Tablas

| Tabla | Qué guarda | Detalles |
|---|---|---|
| `usuarios` | Cuentas | `email` único; contraseña cifrada con bcrypt |
| `categorias` | Catálogo de categorías | 25 categorías iniciales; cada una dice si es de **ingreso o gasto** y si es **fija o variable** |
| `ingresos` | Dinero que entra | Índice por `(usuario_id, fecha)` |
| `gastos` | Dinero que sale | Índice por `(usuario_id, fecha)` |
| `prestamos` | Dinero prestado | — |
| `abonos` | Pagos de préstamos | Se borran solos si se borra el préstamo (`ON DELETE CASCADE`) |
| `metas` | Metas de ahorro | — |
| `movimientos_ahorro` | Depósitos y retiros | Se borran solos si se borra la meta |

### Decisiones de diseño
- **Fijo o variable vive en la categoría,** no en cada movimiento. Así no puede haber un "Arriendo variable" por error.
- **Los saldos no se guardan, se calculan.** El disponible, lo que te deben y lo ahorrado salen de sumar movimientos, así nunca se desincronizan.
- **`DECIMAL(14,2)`** para el dinero, nunca `FLOAT`, para evitar errores de redondeo.
- **`CHECK (monto > 0)`** en la base de datos, como segunda barrera.
- **`ON DELETE CASCADE`:** si se borra un usuario, se borra todo lo suyo.
- **Instalación automática:** al primer uso se crean la base de datos, las tablas y las categorías.

---

## 9. Reglas de negocio

Todas viven en `backend/src/Finanzas.php` y se validan **en el servidor**.

| # | Regla | Mensaje al usuario |
|---|---|---|
| 1 | Un **gasto** no puede superar el disponible | *"No te alcanza para este gasto: tienes $X disponibles y te faltan $Y."* |
| 2 | Un **préstamo** no puede superar el disponible | *"No te alcanza para este préstamo…"* |
| 3 | Un **depósito de ahorro** no puede superar el disponible | *"No te alcanza para guardar ese dinero…"* |
| 4 | Un **abono** no puede superar lo que falta por pagar | *"Andrés solo te debe $X."* |
| 5 | Un **retiro** no puede superar lo ahorrado en la meta | *"'Vacaciones' solo tiene $X ahorrados."* |
| 6 | No se puede **borrar un ingreso** si ese dinero ya se usó | *"No puedes borrar este ingreso: ese dinero ya está gastado, prestado o ahorrado."* |
| 7 | **Copiar fijos** no duplica gastos ya registrados en el mes destino y también exige disponible | *"Los gastos fijos de este mes ya están registrados."* |
| 8 | La **categoría** debe corresponder al tipo de movimiento | *"Elige una categoría válida."* |
| 9 | Los **montos** deben ser mayores que cero | *"Escribe el monto (mayor que cero)."* |
| 10 | Cada usuario solo puede ver y modificar **sus propios datos** | *"Ese registro no existe."* |

**Al eliminar:**
- **Gasto:** el dinero vuelve al disponible.
- **Préstamo:** lo que estaba pendiente vuelve al disponible.
- **Meta:** lo ahorrado vuelve al disponible.

---

## 10. API REST

**URL base:** `/api` · **Formato:** JSON · **Autenticación:** cookie de sesión (`misfinanzas`)

Todas las peticiones `POST` y `DELETE` deben enviar `Content-Type: application/json`.

### Autenticación
| Método | Ruta | Cuerpo | Respuesta |
|---|---|---|---|
| `POST` | `/auth/registro` | `{nombre, email, password}` | `201` `{id, nombre, email}` |
| `POST` | `/auth/login` | `{email, password}` | `200` `{id, nombre, email}` |
| `POST` | `/auth/salir` | `{}` | `{ok: true}` |
| `GET` | `/auth/yo` | — | `{usuario: {...} \| null}` |

### Consultas generales
| Método | Ruta | Descripción |
|---|---|---|
| `GET` | `/categorias` | Catálogo de categorías |
| `GET` | `/saldo` | `{ingresos, gastos, porCobrar, ahorrado, disponible}` |
| `GET` | `/resumen?mes=AAAA-MM` | Totales, datos del mes, gastos por categoría, tendencia de 6 meses y movimientos recientes |

### Ingresos y gastos
| Método | Ruta | Cuerpo / Parámetros |
|---|---|---|
| `GET` | `/ingresos?mes=AAAA-MM` | `mes=todos` para ver todo |
| `POST` | `/ingresos` | `{categoria_id, monto, fecha, descripcion?}` |
| `DELETE` | `/ingresos/{id}` | — |
| `GET` | `/gastos?mes=AAAA-MM` | — |
| `POST` | `/gastos` | `{categoria_id, monto, fecha, descripcion?}` |
| `DELETE` | `/gastos/{id}` | — |
| `POST` | `/gastos/copiar-fijos` | `{mes: "AAAA-MM"}` → `{copiados, total}` |

### Préstamos
| Método | Ruta | Cuerpo |
|---|---|---|
| `GET` | `/prestamos` | Lista con `abonos[]` y `pendiente` |
| `POST` | `/prestamos` | `{persona, monto, fecha, nota?}` |
| `POST` | `/prestamos/{id}/abonos` | `{monto, fecha?}` → `{pendiente}` |
| `DELETE` | `/prestamos/{id}` | — |

### Ahorros
| Método | Ruta | Cuerpo |
|---|---|---|
| `GET` | `/metas` | Lista con `saldo` y los últimos `movimientos[]` |
| `POST` | `/metas` | `{nombre, objetivo}` |
| `POST` | `/metas/{id}/movimientos` | `{tipo: "deposito" \| "retiro", monto}` → `{saldo}` |
| `DELETE` | `/metas/{id}` | — |

### Cuenta
| Método | Ruta | Descripción |
|---|---|---|
| `POST` | `/demo` | Carga datos de ejemplo (solo en una cuenta vacía) |
| `DELETE` | `/datos` | Borra todos los datos del usuario |

### Códigos de respuesta
| Código | Significado |
|---|---|
| `200` / `201` | Correcto / Creado |
| `401` | Sin sesión o credenciales incorrectas |
| `404` | El recurso no existe o no es tuyo |
| `415` | La petición no se envió en JSON |
| `422` | Regla de negocio o validación (ver `error`) |
| `500` | Error del servidor o de la base de datos |

Ejemplo de error:
```json
{ "error": "No te alcanza para este gasto: tienes $ 1.000.000 disponibles y te faltan $ 500.000." }
```

---

## 11. Seguridad

Basada en las recomendaciones de **OWASP** y del **manual de PHP**:

| Medida | Cómo se aplica |
|---|---|
| **Contraseñas cifradas** | `password_hash()` con bcrypt; nunca se guardan en texto plano |
| **Cookie de sesión segura** | `HttpOnly` (JavaScript no puede leerla), `SameSite=Lax`, y `Secure` automático con HTTPS |
| **Modo estricto de sesión** | `session.use_strict_mode` y `session.use_only_cookies` |
| **Contra la fijación de sesión** | `session_regenerate_id(true)` al iniciar sesión |
| **Contra la inyección SQL** | 100 % consultas preparadas con PDO; sin concatenar datos del usuario |
| **Contra CSRF** | `SameSite=Lax` y escrituras solo con `Content-Type: application/json` (un formulario de otro sitio no puede enviarlo) |
| **Contra XSS** | Vue escapa todo el texto automáticamente |
| **Aislamiento de datos** | Cada consulta filtra por `usuario_id` de la sesión |
| **Integridad del dinero** | Reglas en el servidor y transacciones con bloqueo |
| **Errores sin filtrar detalles** | El usuario ve mensajes claros; el detalle técnico va solo al log del servidor |
| **Sin caché de datos privados** | `Cache-Control: no-store` en la API |

> ⚠️ Para publicarla en internet, usa **HTTPS** y considera agregar un límite de intentos de inicio de sesión (ver [Posibles mejoras](#21-posibles-mejoras)).

---

## 12. Diseño y experiencia de usuario

Se investigaron buenas prácticas de apps financieras, de accesibilidad y de diseño para personas con TDAH. Esto es lo que se aplicó:

### Principios
| Principio | Aplicación en la app |
|---|---|
| **Diseño calmado** | Colores neutros, poco ruido visual, un solo color de acento |
| **Siempre claro el siguiente paso** | Botón **+** visible siempre, primeros pasos para cuentas nuevas, sugerencias del mes |
| **No obligar a hacer cuentas mentales** | *"Te quedarán $X"* en vivo, botones "Pagó todo" y "Completar la meta" |
| **Formularios cortos** | Primero el monto (en grande), luego lo demás; la descripción es opcional |
| **Diseño predecible** | La misma estructura en todas las pantallas |
| **Mensajes humanos** | Errores que explican qué pasó y cómo seguir |
| **Confirmar lo irreversible** | Eliminar requiere tocar dos veces |

### Responsive
| Pantalla | Navegación | Formularios |
|---|---|---|
| **Celular** (< 768 px) | Barra inferior + botón flotante **+** | **Hoja que sube desde abajo** (bottom sheet) |
| **Tablet** | Barra inferior o lateral, según el ancho | Ventana centrada |
| **Computador** | Menú lateral con el disponible siempre visible | Ventana centrada |

- Respeta las zonas seguras de celulares con muesca (`safe-area-inset`).
- La hoja se ajusta cuando aparece el teclado (`interactive-widget=resizes-content`).
- Nunca hay dos hojas una encima de otra.

### Accesibilidad
- Navegable con teclado y con foco visible.
- Etiquetas en todos los campos y textos `aria` en los botones de solo ícono.
- **Las animaciones se apagan** si el sistema tiene activado "reducir movimiento".
- **Colores de los gráficos validados** para daltonismo en modo claro y oscuro; la identidad nunca depende solo del color (siempre hay leyenda y etiquetas).
- Números con ancho fijo (`tabular-nums`) para que las columnas queden alineadas.

### Formato local (Colombia)
- Moneda en **pesos colombianos** (`$ 1.500.000`), con `Intl.NumberFormat('es-CO')`.
- Fechas en español: *Hoy*, *Ayer*, *15 de nov*.
- Categorías del contexto local: *maraña*, *arriendo*, *servicios públicos*.

---

## 13. Instalación paso a paso en Windows

> ⏱️ Unos 10 minutos. Haz **un paso a la vez**. Cada parte termina con una ✅ comprobación.

### 🟢 Parte 1 · Instalar XAMPP (solo una vez)
> Si ya tienes XAMPP, salta a la Parte 2.

1. Entra a **https://www.apachefriends.org**
2. Descarga **XAMPP para Windows** (con PHP 8.1 o superior).
3. Abre el instalador. Si Windows pregunta *"¿Permitir cambios?"*, haz clic en **Sí**.
4. Haz clic en **Next** en todas las pantallas, sin cambiar nada, y al final en **Finish**.

✅ **Comprobación:** existe el archivo `C:\xampp\php\php.exe`.

### 🟢 Parte 2 · Activar SQLite (solo una vez)
5. Abre la carpeta `C:\xampp\php`.
6. Haz clic derecho en **`php.ini`** → **Abrir con** → **Bloc de notas**.
7. Presiona `Ctrl + B` (o `Ctrl + F`) y busca **`pdo_sqlite`**.
8. Si la línea dice `;extension=pdo_sqlite`, **borra el `;`** del inicio. Si no tiene `;`, no hagas nada.
9. Guarda con `Ctrl + G` (o `Ctrl + S`) y cierra.

✅ **Comprobación:** la línea queda así: `extension=pdo_sqlite`

### 🟢 Parte 3 · Preparar el proyecto
10. Busca **`finanzas-pro.zip`** en tu carpeta de Descargas.
11. Haz clic derecho → **Extraer todo…** → **Extraer**.
12. Entra a la carpeta **`finanzas-pro`**.

✅ **Comprobación:** ves `backend`, `frontend`, `capturas`, `iniciar.bat` y `README.md`.

### 🟢 Parte 4 · Abrir la app
13. Haz **doble clic** en **`iniciar.bat`**.
14. Si aparece *"Windows protegió su PC"*, haz clic en **Más información** → **Ejecutar de todas formas**.
15. Si el **Firewall** pregunta por `php.exe`, haz clic en **Permitir acceso**.
16. Se abre una **ventana negra** y el navegador.

> ⚠️ **No cierres la ventana negra.** Es el servidor: si la cierras, la app se apaga.

✅ **Comprobación:** el navegador muestra **"Inicia sesión"** en `http://localhost:8000`.

### 🟢 Parte 5 · Primer uso
17. Haz clic en **Crear cuenta**.
18. Escribe tu nombre, tu correo y una contraseña de 8 caracteres o más.
19. Elige:
    - **Usarla de verdad:** sigue los 3 primeros pasos que aparecen en pantalla.
    - **Ver un ejemplo:** tu inicial (el círculo) → **Cargar datos de ejemplo**.

🎉 **¡Listo!**

| Quieres… | Haz esto |
|---|---|
| Abrir la app | Doble clic en `iniciar.bat` |
| Cerrar la app | Cierra la ventana negra |

Tus datos quedan guardados aunque la cierres.

---

## 14. Instalación en Mac o Linux

**1. Instala PHP**

Mac (con [Homebrew](https://brew.sh)):
```bash
brew install php
```

Ubuntu / Debian:
```bash
sudo apt install php-cli php-sqlite3 php-mysql php-mbstring
```

**2. Comprueba la versión** (debe ser 8.1 o superior):
```bash
php -v
```

**3. Descomprime e inicia:**
```bash
unzip finanzas-pro.zip
```
```bash
cd finanzas-pro
```
```bash
./iniciar.sh
```

**4.** Abre **http://localhost:8000**. Para detener la app, presiona `Ctrl + C`.

---

## 15. Usar MySQL en lugar de SQLite

1. Abre el **XAMPP Control Panel** y pulsa **Start** en **MySQL**.
2. Abre `backend/config.php` y cambia esta línea:
   ```php
   'driver'   => getenv('DB_DRIVER') ?: 'sqlite',
   ```
   por:
   ```php
   'driver'   => getenv('DB_DRIVER') ?: 'mysql',
   ```
3. Si tu MySQL tiene contraseña, escríbela en la línea `password`. En XAMPP, por defecto, no tiene.
4. Cierra la ventana negra y vuelve a abrir `iniciar.bat`.

✨ **La base de datos `mis_finanzas` y sus tablas se crean solas.** Puedes verlas en **http://localhost/phpmyadmin**.

**Configuración por defecto:**

| Dato | Valor | Variable de entorno |
|---|---|---|
| Motor | `sqlite` | `DB_DRIVER` |
| Servidor | `127.0.0.1` | `DB_HOST` |
| Puerto | `3306` | `DB_PORT` |
| Base de datos | `mis_finanzas` | `DB_NAME` |
| Usuario | `root` | `DB_USER` |
| Contraseña | *(vacía)* | `DB_PASS` |

> 📄 Para crear las tablas a mano, importa en phpMyAdmin `backend/database/schema.mysql.sql` y luego `backend/database/categorias.sql`.

---

## 16. Guía de uso

### Registrar un ingreso o un gasto
1. Toca el botón **+** (celular) o **Nuevo registro** (computador).
2. Elige **Ingreso** o **Gasto**.
3. Escribe el **monto**. En los gastos verás al instante cuánto te quedará.
4. Elige **Fijo** o **Variable** y luego la **categoría**.
5. La fecha ya viene en **Hoy**. Cámbiala si hace falta.
6. Toca **Registrar**.

### Copiar los gastos fijos de cada mes
En **Gastos**, toca **Copiar fijos del mes anterior**. El arriendo, los servicios y demás se copian con la misma fecha del mes anterior.

### Prestar dinero y registrar pagos
1. **+** → **Préstamo** → monto y persona → **Registrar préstamo**.
2. Cuando te paguen, entra a **Préstamos** → **Registrar pago** → escribe el monto o toca **Pagó todo**.

### Ahorrar
1. **+** → **Meta de ahorro** → nombre y valor objetivo.
2. En **Ahorros**, toca **Guardar** para apartar dinero o **Retirar** para devolverlo a tu disponible.

### Navegar por meses
Usa las flechas **‹ Noviembre de 2026 ›** en Resumen, Ingresos y Gastos.

### Cambiar el tema
Tu inicial (el círculo) → **Apariencia** → Auto, Claro u Oscuro.

---

## 17. Desarrollo

Requiere **Node.js 20+** y **PHP 8.1+**.

**Terminal 1** · API:
```bash
cd backend
```
```bash
php -S localhost:8000 -t public public/index.php
```

**Terminal 2** · Interfaz con recarga automática:
```bash
cd frontend
```
```bash
npm install
```
```bash
npm run dev
```

Abre **http://localhost:5173**. Vite redirige `/api` al servidor PHP.

**Compilar la versión final** (queda en `backend/public`):
```bash
npm run build
```

**Reinstalar las dependencias de PHP** (si borras `vendor/`):
```bash
cd backend
```
```bash
composer install
```

### Agregar una categoría nueva
Insértala en la tabla `categorias`:
```sql
INSERT INTO categorias (movimiento, clase, nombre, icono)
VALUES ('gasto', 'variable', 'Mascotas', 'heart-pulse');
```
Si usas un ícono nuevo, agrégalo en `frontend/src/lib/icons.js`.

---

## 18. Despliegue con Apache

La app debe estar en la **raíz de un dominio**, no en una subcarpeta como `localhost/finanzas`.

```apache
<VirtualHost *:80>
    ServerName misfinanzas.local
    DocumentRoot "C:/ruta/a/finanzas-pro/backend/public"
    <Directory "C:/ruta/a/finanzas-pro/backend/public">
        AllowOverride All
        Require all granted
    </Directory>
</VirtualHost>
```

1. Activa `mod_rewrite`.
2. Agrega `127.0.0.1 misfinanzas.local` a tu archivo `hosts`.
3. Abre `http://misfinanzas.local`.

> 🔒 En un servidor real, usa **HTTPS**. La cookie de sesión se marca como `Secure` automáticamente.

---

## 19. Solución de problemas

| Lo que ves | Qué hacer |
|---|---|
| La ventana negra se abre y se cierra sola | Revisa que exista `C:\xampp\php\php.exe`. Si XAMPP está en otra carpeta, cambia esa ruta en `iniciar.bat`. |
| *"Falta la carpeta vendor"* | Vuelve a descomprimir el zip completo, o ejecuta `composer install` en `backend`. |
| *"could not find driver"* | Activa `extension=pdo_sqlite` (o `pdo_mysql`) en `php.ini` (Parte 2 de la sección 13). |
| *"No pude conectarme a la base de datos"* | Con MySQL: revisa que esté encendido y los datos de `config.php`. Con SQLite: mira el error anterior. |
| *"Call to undefined function mb_substr"* | Activa `extension=mbstring` en `php.ini`. |
| *"Address already in use"* | El puerto 8000 está ocupado: cambia todos los `8000` por `8080` en `iniciar.bat`. |
| *"Falta compilar el frontend"* | Ejecuta `npm run build` en `frontend`. |
| *"Tu sesión terminó"* | Vuelve a iniciar sesión; tus datos siguen guardados. |

🔎 **¿Otro error?** El detalle técnico aparece en la **ventana negra**.

**Empezar de cero:**
- **SQLite:** borra `backend/storage/finanzas.sqlite`.
- **MySQL:** elimina la base de datos `mis_finanzas` en phpMyAdmin.

⚠️ Esto borra todas las cuentas.

---

## 20. Pruebas realizadas

Se verificó en un navegador real (Chromium automatizado con Playwright) y por la API:

| Prueba | Resultado |
|---|---|
| Registro, inicio y cierre de sesión | ✅ |
| Registrar un ingreso y luego un gasto | ✅ El saldo se actualiza al instante |
| Intentar gastar más que el disponible | ✅ Botón desactivado en la interfaz **y** rechazo en el servidor |
| Préstamo mayor que el disponible | ✅ Rechazado |
| Abono mayor que la deuda | ✅ Rechazado |
| Borrar un ingreso ya comprometido | ✅ Rechazado |
| Petición sin sesión | ✅ `401` |
| Petición que no es JSON | ✅ `415` |
| Cookie de sesión | ✅ `HttpOnly`, `SameSite=Lax` |
| Contraseña en la base de datos | ✅ Cifrada con bcrypt (`$2y$…`) |
| Creación automática de tablas en **MySQL (MariaDB)** | ✅ Las 8 tablas |
| Creación automática en **SQLite** | ✅ |
| Copiar gastos fijos | ✅ Sin duplicados |
| Instalación desde el zip, solo con PHP | ✅ |
| Celular (iPhone 13), tablet (820 px) y computador (1366 px) | ✅ Sin desbordes horizontales |
| Modo claro y oscuro | ✅ |
| Errores de JavaScript en consola | ✅ Ninguno |

---

## 21. Posibles mejoras

| Mejora | Valor |
|---|---|
| ✏️ Editar movimientos (hoy se eliminan y se crean de nuevo) | Comodidad |
| ↩️ Botón "Deshacer" después de eliminar | Menos estrés por errores |
| 🔁 Gastos fijos recurrentes automáticos | Ahorra tiempo cada mes |
| 🎯 Presupuesto por categoría con alertas | Control del gasto |
| 📤 Exportar a Excel o PDF | Reportes |
| 🔐 Límite de intentos de inicio de sesión | Seguridad |
| 🔑 Recuperar contraseña por correo | Comodidad |
| 📱 Instalable como app (PWA) | Acceso rápido desde el celular |
| 🧪 Pruebas automáticas (PHPUnit y Vitest) | Calidad del código |

---

<div align="center">

Hecho para Colombia 🇨🇴 · Valores en pesos (COP)

</div>
