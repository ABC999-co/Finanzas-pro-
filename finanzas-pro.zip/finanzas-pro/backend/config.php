<?php
/*
 * Configuración de la base de datos.
 *
 * 'driver' => 'sqlite'  Funciona sin instalar nada (archivo en storage/finanzas.sqlite).
 * 'driver' => 'mysql'   Usa MySQL/MariaDB (por ejemplo el de XAMPP).
 *                       La base de datos y las tablas se crean solas.
 *
 * También puedes usar variables de entorno: DB_DRIVER, DB_HOST, DB_PORT, DB_NAME, DB_USER, DB_PASS.
 */
return [
    'driver'   => getenv('DB_DRIVER') ?: 'sqlite',
    'sqlite'   => __DIR__ . '/storage/finanzas.sqlite',
    'host'     => getenv('DB_HOST') ?: '127.0.0.1',
    'port'     => getenv('DB_PORT') ?: '3306',
    'database' => getenv('DB_NAME') ?: 'mis_finanzas',
    'username' => getenv('DB_USER') ?: 'root',
    'password' => getenv('DB_PASS') !== false ? getenv('DB_PASS') : '',
];
