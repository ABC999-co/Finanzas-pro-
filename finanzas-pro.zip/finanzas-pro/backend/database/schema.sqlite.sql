-- Mis Finanzas · Esquema SQLite
-- La app crea estas tablas sola la primera vez. Este archivo sirve como documentación
-- o para crearlas a mano desde phpMyAdmin.

CREATE TABLE IF NOT EXISTS usuarios (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  nombre        VARCHAR(80)  NOT NULL,
  email         VARCHAR(120) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  creado_en     DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- Catálogo: cada categoría dice si es de ingreso o gasto y si es fija o variable
CREATE TABLE IF NOT EXISTS categorias (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  movimiento VARCHAR(10) NOT NULL CHECK (movimiento IN ('ingreso','gasto')),
  clase      VARCHAR(10) NOT NULL CHECK (clase IN ('fijo','variable')),
  nombre     VARCHAR(60) NOT NULL,
  icono      VARCHAR(30) NOT NULL DEFAULT 'circle',
  UNIQUE (movimiento, nombre)
);

CREATE TABLE IF NOT EXISTS ingresos (
  id           INTEGER PRIMARY KEY AUTOINCREMENT,
  usuario_id   INTEGER  NOT NULL,
  categoria_id INTEGER  NOT NULL,
  descripcion  VARCHAR(120)  NOT NULL DEFAULT '',
  monto        DECIMAL(14,2) NOT NULL CHECK (monto > 0),
  fecha        DATE          NOT NULL,
  creado_en    DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (usuario_id)   REFERENCES usuarios(id)   ON DELETE CASCADE,
  FOREIGN KEY (categoria_id) REFERENCES categorias(id)
);

CREATE TABLE IF NOT EXISTS gastos (
  id           INTEGER PRIMARY KEY AUTOINCREMENT,
  usuario_id   INTEGER  NOT NULL,
  categoria_id INTEGER  NOT NULL,
  descripcion  VARCHAR(120)  NOT NULL DEFAULT '',
  monto        DECIMAL(14,2) NOT NULL CHECK (monto > 0),
  fecha        DATE          NOT NULL,
  creado_en    DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (usuario_id)   REFERENCES usuarios(id)   ON DELETE CASCADE,
  FOREIGN KEY (categoria_id) REFERENCES categorias(id)
);

CREATE TABLE IF NOT EXISTS prestamos (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  usuario_id INTEGER  NOT NULL,
  persona    VARCHAR(80)   NOT NULL,
  monto      DECIMAL(14,2) NOT NULL CHECK (monto > 0),
  fecha      DATE          NOT NULL,
  nota       VARCHAR(120)  NOT NULL DEFAULT '',
  creado_en  DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE
);

-- Pagos que te hacen de un préstamo (vuelven a tu disponible)
CREATE TABLE IF NOT EXISTS abonos (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  prestamo_id INTEGER  NOT NULL,
  monto       DECIMAL(14,2) NOT NULL CHECK (monto > 0),
  fecha       DATE          NOT NULL,
  FOREIGN KEY (prestamo_id) REFERENCES prestamos(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS metas (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  usuario_id INTEGER  NOT NULL,
  nombre     VARCHAR(80)   NOT NULL,
  objetivo   DECIMAL(14,2) NOT NULL CHECK (objetivo > 0),
  creado_en  DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE
);

-- Depósitos (salen del disponible) y retiros (vuelven al disponible)
CREATE TABLE IF NOT EXISTS movimientos_ahorro (
  id      INTEGER PRIMARY KEY AUTOINCREMENT,
  meta_id INTEGER  NOT NULL,
  tipo    VARCHAR(10)   NOT NULL CHECK (tipo IN ('deposito','retiro')),
  monto   DECIMAL(14,2) NOT NULL CHECK (monto > 0),
  fecha   DATE          NOT NULL,
  FOREIGN KEY (meta_id) REFERENCES metas(id) ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_ing_usuario_fecha ON ingresos (usuario_id, fecha);
CREATE INDEX IF NOT EXISTS idx_gas_usuario_fecha ON gastos (usuario_id, fecha);
