-- Mis Finanzas · Esquema MySQL / MariaDB
-- La app crea estas tablas sola la primera vez. Este archivo sirve como documentación
-- o para crearlas a mano desde phpMyAdmin.

CREATE TABLE IF NOT EXISTS usuarios (
  id            INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  nombre        VARCHAR(80)  NOT NULL,
  email         VARCHAR(120) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  creado_en     DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Catálogo: cada categoría dice si es de ingreso o gasto y si es fija o variable
CREATE TABLE IF NOT EXISTS categorias (
  id         INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  movimiento VARCHAR(10) NOT NULL CHECK (movimiento IN ('ingreso','gasto')),
  clase      VARCHAR(10) NOT NULL CHECK (clase IN ('fijo','variable')),
  nombre     VARCHAR(60) NOT NULL,
  icono      VARCHAR(30) NOT NULL DEFAULT 'circle',
  UNIQUE KEY uq_categoria (movimiento, nombre)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS ingresos (
  id           INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  usuario_id   INT UNSIGNED  NOT NULL,
  categoria_id INT UNSIGNED  NOT NULL,
  descripcion  VARCHAR(120)  NOT NULL DEFAULT '',
  monto        DECIMAL(14,2) NOT NULL CHECK (monto > 0),
  fecha        DATE          NOT NULL,
  creado_en    DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_ing_usuario_fecha (usuario_id, fecha),
  FOREIGN KEY (usuario_id)   REFERENCES usuarios(id)   ON DELETE CASCADE,
  FOREIGN KEY (categoria_id) REFERENCES categorias(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS gastos (
  id           INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  usuario_id   INT UNSIGNED  NOT NULL,
  categoria_id INT UNSIGNED  NOT NULL,
  descripcion  VARCHAR(120)  NOT NULL DEFAULT '',
  monto        DECIMAL(14,2) NOT NULL CHECK (monto > 0),
  fecha        DATE          NOT NULL,
  creado_en    DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_gas_usuario_fecha (usuario_id, fecha),
  FOREIGN KEY (usuario_id)   REFERENCES usuarios(id)   ON DELETE CASCADE,
  FOREIGN KEY (categoria_id) REFERENCES categorias(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS prestamos (
  id         INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  usuario_id INT UNSIGNED  NOT NULL,
  persona    VARCHAR(80)   NOT NULL,
  monto      DECIMAL(14,2) NOT NULL CHECK (monto > 0),
  fecha      DATE          NOT NULL,
  nota       VARCHAR(120)  NOT NULL DEFAULT '',
  creado_en  DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Pagos que te hacen de un préstamo (vuelven a tu disponible)
CREATE TABLE IF NOT EXISTS abonos (
  id          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  prestamo_id INT UNSIGNED  NOT NULL,
  monto       DECIMAL(14,2) NOT NULL CHECK (monto > 0),
  fecha       DATE          NOT NULL,
  FOREIGN KEY (prestamo_id) REFERENCES prestamos(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS metas (
  id         INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  usuario_id INT UNSIGNED  NOT NULL,
  nombre     VARCHAR(80)   NOT NULL,
  objetivo   DECIMAL(14,2) NOT NULL CHECK (objetivo > 0),
  creado_en  DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Depósitos (salen del disponible) y retiros (vuelven al disponible)
CREATE TABLE IF NOT EXISTS movimientos_ahorro (
  id      INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  meta_id INT UNSIGNED  NOT NULL,
  tipo    VARCHAR(10)   NOT NULL CHECK (tipo IN ('deposito','retiro')),
  monto   DECIMAL(14,2) NOT NULL CHECK (monto > 0),
  fecha   DATE          NOT NULL,
  FOREIGN KEY (meta_id) REFERENCES metas(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
