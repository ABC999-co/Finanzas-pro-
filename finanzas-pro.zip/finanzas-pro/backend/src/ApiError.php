<?php
namespace App;

/** Error con mensaje claro para mostrar al usuario y su código HTTP. */
final class ApiError extends \RuntimeException
{
    public function __construct(string $message, public readonly int $status = 422)
    {
        parent::__construct($message);
    }
}
