<?php
namespace App;

use PDO;

/** Registro e inicio de sesión con contraseñas cifradas (password_hash). */
final class Auth
{
    public static function usuarioId(): ?int
    {
        return isset($_SESSION['uid']) ? (int) $_SESSION['uid'] : null;
    }

    public static function registrar(PDO $db, array $d): array
    {
        $nombre = Validar::texto($d['nombre'] ?? '', 80, 'tu nombre');
        $email = mb_strtolower(trim((string) ($d['email'] ?? '')));
        $pass = (string) ($d['password'] ?? '');
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) throw new ApiError('Escribe un correo válido.');
        if (mb_strlen($pass) < 8) throw new ApiError('La contraseña debe tener al menos 8 caracteres.');
        $st = $db->prepare('SELECT 1 FROM usuarios WHERE email = ?');
        $st->execute([$email]);
        if ($st->fetchColumn()) throw new ApiError('Ya existe una cuenta con ese correo. Inicia sesión.');
        $db->prepare('INSERT INTO usuarios (nombre, email, password_hash) VALUES (?,?,?)')
            ->execute([$nombre, $email, password_hash($pass, PASSWORD_DEFAULT)]);
        return self::iniciar((int) $db->lastInsertId(), $nombre, $email);
    }

    public static function login(PDO $db, array $d): array
    {
        $email = mb_strtolower(trim((string) ($d['email'] ?? '')));
        $st = $db->prepare('SELECT id, nombre, email, password_hash FROM usuarios WHERE email = ?');
        $st->execute([$email]);
        $u = $st->fetch();
        if (!$u || !password_verify((string) ($d['password'] ?? ''), $u['password_hash'])) {
            throw new ApiError('El correo o la contraseña no coinciden.', 401);
        }
        return self::iniciar((int) $u['id'], $u['nombre'], $u['email']);
    }

    public static function yo(PDO $db): ?array
    {
        $id = self::usuarioId();
        if (!$id) return null;
        $st = $db->prepare('SELECT id, nombre, email FROM usuarios WHERE id = ?');
        $st->execute([$id]);
        $u = $st->fetch();
        if ($u) $u['id'] = (int) $u['id'];
        return $u ?: null;
    }

    public static function salir(): void
    {
        $_SESSION = [];
        session_destroy();
    }

    private static function iniciar(int $id, string $nombre, string $email): array
    {
        session_regenerate_id(true);
        $_SESSION['uid'] = $id;
        return ['id' => $id, 'nombre' => $nombre, 'email' => $email];
    }
}
