<?php
namespace App;

use PDO;

/**
 * Reglas de negocio. Todo está conectado a un solo número:
 *
 *   DISPONIBLE = ingresos − gastos − (préstamos − abonos) − (depósitos − retiros)
 *
 * Ningún gasto, préstamo o depósito de ahorro puede superar el disponible.
 */
final class Finanzas
{
    public function __construct(private PDO $db, private int $uid) {}

    /* ---------- Cálculos ---------- */

    private function scalar(string $sql, array $params = []): float
    {
        $st = $this->db->prepare($sql);
        $st->execute($params);
        return (float) ($st->fetchColumn() ?: 0);
    }

    public function totales(): array
    {
        $u = [$this->uid];
        $ingresos  = $this->scalar('SELECT COALESCE(SUM(monto),0) FROM ingresos WHERE usuario_id = ?', $u);
        $gastos    = $this->scalar('SELECT COALESCE(SUM(monto),0) FROM gastos WHERE usuario_id = ?', $u);
        $prestado  = $this->scalar('SELECT COALESCE(SUM(monto),0) FROM prestamos WHERE usuario_id = ?', $u);
        $abonado   = $this->scalar('SELECT COALESCE(SUM(a.monto),0) FROM abonos a JOIN prestamos p ON p.id = a.prestamo_id WHERE p.usuario_id = ?', $u);
        $depositos = $this->scalar("SELECT COALESCE(SUM(m.monto),0) FROM movimientos_ahorro m JOIN metas t ON t.id = m.meta_id WHERE t.usuario_id = ? AND m.tipo = 'deposito'", $u);
        $retiros   = $this->scalar("SELECT COALESCE(SUM(m.monto),0) FROM movimientos_ahorro m JOIN metas t ON t.id = m.meta_id WHERE t.usuario_id = ? AND m.tipo = 'retiro'", $u);
        $porCobrar = $prestado - $abonado;
        $ahorrado  = $depositos - $retiros;
        return [
            'ingresos'   => $ingresos,
            'gastos'     => $gastos,
            'porCobrar'  => $porCobrar,
            'ahorrado'   => $ahorrado,
            'disponible' => $ingresos - $gastos - $porCobrar - $ahorrado,
        ];
    }

    public function disponible(): float { return $this->totales()['disponible']; }

    private function exigirDisponible(float $monto, string $accion): void
    {
        $d = $this->disponible();
        if ($monto > $d) {
            throw new ApiError(sprintf(
                'No te alcanza para %s: tienes %s disponibles y te faltan %s.',
                $accion, Validar::pesos($d), Validar::pesos($monto - $d)
            ));
        }
    }

    /* ---------- Ingresos y gastos ---------- */

    public function listarMovimientos(string $tabla, ?string $mes): array
    {
        [$sqlMes, $params] = $this->filtroMes($mes, 'm.fecha');
        $st = $this->db->prepare("SELECT m.id, m.descripcion, m.monto, m.fecha, c.id AS categoria_id, c.nombre AS categoria, c.clase, c.icono
            FROM $tabla m JOIN categorias c ON c.id = m.categoria_id
            WHERE m.usuario_id = ? $sqlMes ORDER BY m.fecha DESC, m.id DESC");
        $st->execute([$this->uid, ...$params]);
        return array_map([$this, 'num'], $st->fetchAll());
    }

    public function crearMovimiento(string $tabla, array $d): array
    {
        $tipo = $tabla === 'ingresos' ? 'ingreso' : 'gasto';
        $cat = $this->categoria((int) ($d['categoria_id'] ?? 0), $tipo);
        $monto = Validar::monto($d['monto'] ?? null);
        $fecha = Validar::fecha($d['fecha'] ?? null);
        $desc = Validar::texto($d['descripcion'] ?? '', 120);
        if ($tipo === 'gasto') $this->exigirDisponible($monto, 'este gasto');
        $this->db->prepare("INSERT INTO $tabla (usuario_id, categoria_id, descripcion, monto, fecha) VALUES (?,?,?,?,?)")
            ->execute([$this->uid, $cat['id'], $desc, $monto, $fecha]);
        return ['id' => (int) $this->db->lastInsertId()];
    }

    public function eliminarMovimiento(string $tabla, int $id): void
    {
        $st = $this->db->prepare("SELECT monto FROM $tabla WHERE id = ? AND usuario_id = ?");
        $st->execute([$id, $this->uid]);
        $monto = $st->fetchColumn();
        if ($monto === false) throw new ApiError('Ese registro no existe.', 404);
        if ($tabla === 'ingresos' && $this->disponible() - (float) $monto < 0) {
            throw new ApiError('No puedes borrar este ingreso: ese dinero ya está gastado, prestado o ahorrado.');
        }
        $this->db->prepare("DELETE FROM $tabla WHERE id = ? AND usuario_id = ?")->execute([$id, $this->uid]);
    }

    /** Copia los gastos fijos del mes anterior al mes indicado (sin duplicar). */
    public function copiarFijos(string $mes): array
    {
        $mes = Validar::mes($mes);
        $ini = new \DateTimeImmutable("$mes-01");
        $prev = $ini->modify('-1 month');
        $st = $this->db->prepare("SELECT g.categoria_id, g.descripcion, g.monto, g.fecha FROM gastos g
            JOIN categorias c ON c.id = g.categoria_id
            WHERE g.usuario_id = ? AND c.clase = 'fijo' AND g.fecha >= ? AND g.fecha < ?");
        $st->execute([$this->uid, $prev->format('Y-m-d'), $ini->format('Y-m-d')]);
        $origen = $st->fetchAll();
        if (!$origen) throw new ApiError('El mes anterior no tiene gastos fijos para copiar.');

        $existe = $this->db->prepare('SELECT 1 FROM gastos WHERE usuario_id = ? AND categoria_id = ? AND descripcion = ? AND fecha >= ? AND fecha < ?');
        $nuevos = [];
        foreach ($origen as $g) {
            $existe->execute([$this->uid, $g['categoria_id'], $g['descripcion'], $ini->format('Y-m-d'), $ini->modify('+1 month')->format('Y-m-d')]);
            if ($existe->fetchColumn()) continue;
            $dia = min((int) substr($g['fecha'], 8, 2), (int) $ini->format('t'));
            $nuevos[] = [$g['categoria_id'], $g['descripcion'], (float) $g['monto'], $ini->format('Y-m-') . str_pad((string) $dia, 2, '0', STR_PAD_LEFT)];
        }
        if (!$nuevos) throw new ApiError('Los gastos fijos de este mes ya están registrados.');
        $this->exigirDisponible(array_sum(array_column($nuevos, 2)), 'copiar los gastos fijos');
        $ins = $this->db->prepare('INSERT INTO gastos (usuario_id, categoria_id, descripcion, monto, fecha) VALUES (?,?,?,?,?)');
        foreach ($nuevos as $n) $ins->execute([$this->uid, ...$n]);
        return ['copiados' => count($nuevos), 'total' => array_sum(array_column($nuevos, 2))];
    }

    /* ---------- Préstamos ---------- */

    public function listarPrestamos(): array
    {
        $st = $this->db->prepare('SELECT id, persona, monto, fecha, nota FROM prestamos WHERE usuario_id = ? ORDER BY fecha DESC, id DESC');
        $st->execute([$this->uid]);
        $prestamos = array_map([$this, 'num'], $st->fetchAll());
        $ab = $this->db->prepare('SELECT id, monto, fecha FROM abonos WHERE prestamo_id = ? ORDER BY fecha, id');
        foreach ($prestamos as &$p) {
            $ab->execute([$p['id']]);
            $p['abonos'] = array_map([$this, 'num'], $ab->fetchAll());
            $p['pendiente'] = $p['monto'] - array_sum(array_column($p['abonos'], 'monto'));
        }
        return $prestamos;
    }

    public function crearPrestamo(array $d): array
    {
        $persona = Validar::texto($d['persona'] ?? '', 80, 'el nombre de la persona');
        $monto = Validar::monto($d['monto'] ?? null);
        $fecha = Validar::fecha($d['fecha'] ?? null);
        $nota = Validar::texto($d['nota'] ?? '', 120);
        $this->exigirDisponible($monto, 'este préstamo');
        $this->db->prepare('INSERT INTO prestamos (usuario_id, persona, monto, fecha, nota) VALUES (?,?,?,?,?)')
            ->execute([$this->uid, $persona, $monto, $fecha, $nota]);
        return ['id' => (int) $this->db->lastInsertId()];
    }

    public function abonar(int $prestamoId, array $d): array
    {
        $p = $this->prestamo($prestamoId);
        $monto = Validar::monto($d['monto'] ?? null);
        $fecha = Validar::fecha($d['fecha'] ?? date('Y-m-d'));
        if ($monto > $p['pendiente']) {
            throw new ApiError(sprintf('%s solo te debe %s.', $p['persona'], Validar::pesos($p['pendiente'])));
        }
        $this->db->prepare('INSERT INTO abonos (prestamo_id, monto, fecha) VALUES (?,?,?)')->execute([$prestamoId, $monto, $fecha]);
        return ['pendiente' => $p['pendiente'] - $monto];
    }

    public function eliminarPrestamo(int $id): void
    {
        $this->prestamo($id);
        $this->db->prepare('DELETE FROM prestamos WHERE id = ? AND usuario_id = ?')->execute([$id, $this->uid]);
    }

    private function prestamo(int $id): array
    {
        $st = $this->db->prepare('SELECT p.id, p.persona, p.monto - COALESCE((SELECT SUM(a.monto) FROM abonos a WHERE a.prestamo_id = p.id),0) AS pendiente
            FROM prestamos p WHERE p.id = ? AND p.usuario_id = ?');
        $st->execute([$id, $this->uid]);
        $p = $st->fetch();
        if (!$p) throw new ApiError('Ese préstamo no existe.', 404);
        $p['pendiente'] = (float) $p['pendiente'];
        return $p;
    }

    /* ---------- Ahorros ---------- */

    public function listarMetas(): array
    {
        $st = $this->db->prepare("SELECT t.id, t.nombre, t.objetivo,
              COALESCE(SUM(CASE WHEN m.tipo = 'deposito' THEN m.monto WHEN m.tipo = 'retiro' THEN -m.monto END),0) AS saldo
            FROM metas t LEFT JOIN movimientos_ahorro m ON m.meta_id = t.id
            WHERE t.usuario_id = ? GROUP BY t.id, t.nombre, t.objetivo ORDER BY t.id");
        $st->execute([$this->uid]);
        $metas = array_map([$this, 'num'], $st->fetchAll());
        $mv = $this->db->prepare('SELECT id, tipo, monto, fecha FROM movimientos_ahorro WHERE meta_id = ? ORDER BY fecha DESC, id DESC LIMIT 5');
        foreach ($metas as &$m) { $mv->execute([$m['id']]); $m['movimientos'] = array_map([$this, 'num'], $mv->fetchAll()); }
        return $metas;
    }

    public function crearMeta(array $d): array
    {
        $nombre = Validar::texto($d['nombre'] ?? '', 80, 'el nombre de la meta');
        $objetivo = Validar::monto($d['objetivo'] ?? null, 'el valor de la meta');
        $this->db->prepare('INSERT INTO metas (usuario_id, nombre, objetivo) VALUES (?,?,?)')->execute([$this->uid, $nombre, $objetivo]);
        return ['id' => (int) $this->db->lastInsertId()];
    }

    public function moverAhorro(int $metaId, array $d): array
    {
        $meta = null;
        foreach ($this->listarMetas() as $m) if ($m['id'] === $metaId) $meta = $m;
        if (!$meta) throw new ApiError('Esa meta no existe.', 404);
        $tipo = ($d['tipo'] ?? '') === 'retiro' ? 'retiro' : 'deposito';
        $monto = Validar::monto($d['monto'] ?? null);
        if ($tipo === 'deposito') $this->exigirDisponible($monto, 'guardar ese dinero');
        if ($tipo === 'retiro' && $monto > $meta['saldo']) {
            throw new ApiError(sprintf('“%s” solo tiene %s ahorrados.', $meta['nombre'], Validar::pesos($meta['saldo'])));
        }
        $this->db->prepare('INSERT INTO movimientos_ahorro (meta_id, tipo, monto, fecha) VALUES (?,?,?,?)')
            ->execute([$metaId, $tipo, $monto, date('Y-m-d')]);
        return ['saldo' => $meta['saldo'] + ($tipo === 'deposito' ? $monto : -$monto)];
    }

    public function eliminarMeta(int $id): void
    {
        $st = $this->db->prepare('DELETE FROM metas WHERE id = ? AND usuario_id = ?');
        $st->execute([$id, $this->uid]);
        if (!$st->rowCount()) throw new ApiError('Esa meta no existe.', 404);
    }

    /* ---------- Resumen ---------- */

    public function resumen(?string $mes): array
    {
        $mes = Validar::mes($mes ?: date('Y-m'));
        $ini = new \DateTimeImmutable("$mes-01");
        $ing = $this->listarMovimientos('ingresos', $mes);
        $gas = $this->listarMovimientos('gastos', $mes);
        $sumClase = fn($rows, $c) => array_sum(array_column(array_filter($rows, fn($r) => $r['clase'] === $c), 'monto'));

        $porCategoria = [];
        foreach ($gas as $g) {
            $k = $g['categoria'];
            $porCategoria[$k] ??= ['categoria' => $k, 'icono' => $g['icono'], 'clase' => $g['clase'], 'total' => 0];
            $porCategoria[$k]['total'] += $g['monto'];
        }
        usort($porCategoria, fn($a, $b) => $b['total'] <=> $a['total']);

        // Tendencia: últimos 6 meses
        $desde = $ini->modify('-5 months');
        $hasta = $ini->modify('+1 month');
        $serie = [];
        for ($d = $desde; $d < $hasta; $d = $d->modify('+1 month')) $serie[$d->format('Y-m')] = ['mes' => $d->format('Y-m'), 'ingresos' => 0, 'gastos' => 0];
        foreach (['ingresos', 'gastos'] as $t) {
            $st = $this->db->prepare("SELECT fecha, monto FROM $t WHERE usuario_id = ? AND fecha >= ? AND fecha < ?");
            $st->execute([$this->uid, $desde->format('Y-m-d'), $hasta->format('Y-m-d')]);
            foreach ($st->fetchAll() as $r) $serie[substr($r['fecha'], 0, 7)][$t] += (float) $r['monto'];
        }

        return [
            'mes' => $mes,
            'totales' => $this->totales(),
            'delMes' => [
                'ingresosFijos' => $sumClase($ing, 'fijo'), 'ingresosVariables' => $sumClase($ing, 'variable'),
                'gastosFijos' => $sumClase($gas, 'fijo'), 'gastosVariables' => $sumClase($gas, 'variable'),
            ],
            'gastosPorCategoria' => array_values($porCategoria),
            'tendencia' => array_values($serie),
            'recientes' => $this->recientes(),
        ];
    }

    private function recientes(): array
    {
        $u = $this->uid;
        $sql = "SELECT * FROM (
            SELECT 'ingreso' AS tipo, c.nombre AS titulo, i.descripcion AS detalle, i.monto, i.fecha, i.id FROM ingresos i JOIN categorias c ON c.id = i.categoria_id WHERE i.usuario_id = $u
            UNION ALL SELECT 'gasto', c.nombre, g.descripcion, g.monto, g.fecha, g.id FROM gastos g JOIN categorias c ON c.id = g.categoria_id WHERE g.usuario_id = $u
            UNION ALL SELECT 'prestamo', p.persona, 'Préstamo', p.monto, p.fecha, p.id FROM prestamos p WHERE p.usuario_id = $u
            UNION ALL SELECT 'abono', p.persona, 'Te abonó', a.monto, a.fecha, a.id FROM abonos a JOIN prestamos p ON p.id = a.prestamo_id WHERE p.usuario_id = $u
            UNION ALL SELECT m.tipo, t.nombre, 'Ahorro', m.monto, m.fecha, m.id FROM movimientos_ahorro m JOIN metas t ON t.id = m.meta_id WHERE t.usuario_id = $u
        ) x ORDER BY fecha DESC, id DESC LIMIT 8";
        return array_map([$this, 'num'], $this->db->query($sql)->fetchAll());
    }

    /* ---------- Datos de ejemplo y borrado ---------- */

    public function cargarEjemplo(): void
    {
        $t = $this->totales();
        if ($t['ingresos'] || $t['gastos']) throw new ApiError('Ya tienes datos. Los ejemplos solo se cargan en una cuenta vacía.');
        $cat = fn($n) => (int) $this->db->query('SELECT id FROM categorias WHERE nombre = ' . $this->db->quote($n))->fetchColumn();
        $m0 = new \DateTimeImmutable('first day of this month');
        $ins = fn($tabla, $c, $desc, $monto, $f) => $this->db->prepare("INSERT INTO $tabla (usuario_id, categoria_id, descripcion, monto, fecha) VALUES (?,?,?,?,?)")
            ->execute([$this->uid, $cat($c), $desc, $monto, $f]);
        for ($k = 3; $k >= 0; $k--) {
            $m = $m0->modify("-$k months");
            $d = fn($day) => $m->format('Y-m-') . str_pad((string) $day, 2, '0', STR_PAD_LEFT);
            $ins('ingresos', 'Salario', 'Quincena 1', 1600000, $d(1));
            $ins('ingresos', 'Salario', 'Quincena 2', 1600000, $d(15));
            $ins('ingresos', 'Maraña', 'Arreglo de computador', [180000, 120000, 250000, 90000][$k], $d(8));
            $ins('gastos', 'Arriendo', 'Apartamento', 950000, $d(2));
            $ins('gastos', 'Servicios públicos', 'Agua, luz y gas', [205000, 198000, 221000, 210000][$k], $d(5));
            $ins('gastos', 'Internet y celular', 'Plan hogar', 95000, $d(6));
            $ins('gastos', 'Almuerzos', 'Semana de trabajo', [310000, 280000, 295000, 85000][$k], $d(9));
            $ins('gastos', 'Gasolina', 'Moto', [160000, 150000, 170000, 40000][$k], $d(10));
            $ins('gastos', 'Mercado', 'Mercado del mes', [420000, 390000, 450000, 260000][$k], $d(12));
            if ($k !== 0) $ins('gastos', 'Salidas', 'Cine y comida', [0, 140000, 95000, 120000][$k], $d(20));
        }
        $hoy = date('Y-m-d');
        $this->db->prepare('INSERT INTO prestamos (usuario_id, persona, monto, fecha, nota) VALUES (?,?,?,?,?)')->execute([$this->uid, 'Andrés', 200000, $m0->format('Y-m-07'), 'Paga a fin de mes']);
        $this->db->prepare('INSERT INTO abonos (prestamo_id, monto, fecha) VALUES (?,?,?)')->execute([(int) $this->db->lastInsertId(), 50000, $hoy]);
        foreach ([['Fondo de emergencia', 3000000, 900000], ['Vacaciones en diciembre', 1500000, 400000]] as [$n, $obj, $dep]) {
            $this->db->prepare('INSERT INTO metas (usuario_id, nombre, objetivo) VALUES (?,?,?)')->execute([$this->uid, $n, $obj]);
            $this->db->prepare("INSERT INTO movimientos_ahorro (meta_id, tipo, monto, fecha) VALUES (?, 'deposito', ?, ?)")->execute([(int) $this->db->lastInsertId(), $dep, $hoy]);
        }
    }

    public function borrarTodo(): void
    {
        foreach (['ingresos', 'gastos', 'prestamos', 'metas'] as $t) {
            $this->db->prepare("DELETE FROM $t WHERE usuario_id = ?")->execute([$this->uid]);
        }
    }

    /* ---------- Ayudas ---------- */

    public function categorias(): array
    {
        return array_map([$this, 'num'], $this->db->query('SELECT id, movimiento, clase, nombre, icono FROM categorias ORDER BY id')->fetchAll());
    }

    private function categoria(int $id, string $tipo): array
    {
        $st = $this->db->prepare('SELECT id, clase FROM categorias WHERE id = ? AND movimiento = ?');
        $st->execute([$id, $tipo]);
        return $st->fetch() ?: throw new ApiError('Elige una categoría válida.');
    }

    private function filtroMes(?string $mes, string $col): array
    {
        if (!$mes || $mes === 'todos') return ['', []];
        $ini = new \DateTimeImmutable(Validar::mes($mes) . '-01');
        return ["AND $col >= ? AND $col < ?", [$ini->format('Y-m-d'), $ini->modify('+1 month')->format('Y-m-d')]];
    }

    /** Convierte columnas numéricas que PDO devuelve como texto. */
    private function num(array $r): array
    {
        foreach (['id', 'categoria_id'] as $k) if (isset($r[$k])) $r[$k] = (int) $r[$k];
        foreach (['monto', 'objetivo', 'saldo'] as $k) if (isset($r[$k])) $r[$k] = (float) $r[$k];
        return $r;
    }
}
