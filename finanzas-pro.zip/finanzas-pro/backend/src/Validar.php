<?php
namespace App;

/** Validaciones con mensajes en español, pensados para el usuario final. */
final class Validar
{
    public static function monto(mixed $v, string $que = 'el monto'): float
    {
        if (!is_numeric($v) || (float) $v <= 0) throw new ApiError("Escribe $que (mayor que cero).");
        $n = round((float) $v, 2);
        if ($n > 999999999999) throw new ApiError(ucfirst($que) . ' es demasiado grande.');
        return $n;
    }

    public static function fecha(mixed $v): string
    {
        $d = \DateTimeImmutable::createFromFormat('!Y-m-d', (string) $v);
        if (!$d || $d->format('Y-m-d') !== $v) throw new ApiError('Elige una fecha válida.');
        return $v;
    }

    public static function mes(mixed $v): string
    {
        if (!is_string($v) || !preg_match('/^\d{4}-(0[1-9]|1[0-2])$/', $v)) throw new ApiError('Mes no válido.');
        return $v;
    }

    public static function texto(mixed $v, int $max, ?string $obligatorio = null): string
    {
        $t = trim((string) $v);
        if ($obligatorio && $t === '') throw new ApiError("Escribe $obligatorio.");
        return mb_substr($t, 0, $max);
    }

    public static function pesos(float $n): string
    {
        return '$ ' . number_format($n, 0, ',', '.');
    }
}
