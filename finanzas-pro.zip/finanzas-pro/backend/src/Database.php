<?php
namespace App;

use PDO;

/** Conexión PDO (MySQL o SQLite) que crea las tablas sola la primera vez. */
final class Database
{
    private static ?PDO $pdo = null;
    private static string $driver = 'sqlite';

    public static function pdo(): PDO
    {
        if (self::$pdo) return self::$pdo;
        $c = require __DIR__ . '/../config.php';
        self::$driver = $c['driver'];
        $opts = [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
        ];
        if (self::$driver === 'mysql') {
            $server = "mysql:host={$c['host']};port={$c['port']};charset=utf8mb4";
            $pdo = new PDO($server, $c['username'], $c['password'], $opts);
            $db = str_replace('`', '', $c['database']);
            $pdo->exec("CREATE DATABASE IF NOT EXISTS `$db` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
            $pdo->exec("USE `$db`");
        } else {
            if (!is_dir(dirname($c['sqlite']))) mkdir(dirname($c['sqlite']), 0775, true);
            $pdo = new PDO('sqlite:' . $c['sqlite'], null, null, $opts);
            $pdo->exec('PRAGMA foreign_keys = ON');
            $pdo->exec('PRAGMA journal_mode = WAL');
        }
        self::$pdo = $pdo;
        self::migrate();
        return $pdo;
    }

    public static function isMysql(): bool { return self::$driver === 'mysql'; }

    /** Crea tablas y categorías si todavía no existen. */
    private static function migrate(): void
    {
        $pdo = self::$pdo;
        try {
            if ((int) $pdo->query('SELECT COUNT(*) FROM categorias')->fetchColumn() > 0) return; // ya instalada
        } catch (\PDOException) {}
        $file = __DIR__ . '/../database/schema.' . (self::isMysql() ? 'mysql' : 'sqlite') . '.sql';
        foreach (self::statements(file_get_contents($file)) as $sql) $pdo->exec($sql);
        foreach (self::statements(file_get_contents(__DIR__ . '/../database/categorias.sql')) as $sql) $pdo->exec($sql);
    }

    private static function statements(string $sql): array
    {
        $sql = preg_replace('/^\s*--.*$/m', '', $sql);
        return array_filter(array_map('trim', explode(';', $sql)));
    }

    /**
     * Ejecuta $fn dentro de una transacción bloqueando al usuario,
     * para que dos operaciones simultáneas no gasten el mismo dinero.
     */
    public static function transaction(int $userId, callable $fn): mixed
    {
        $pdo = self::pdo();
        if (self::isMysql()) {
            $pdo->beginTransaction();
            $pdo->prepare('SELECT id FROM usuarios WHERE id = ? FOR UPDATE')->execute([$userId]);
        } else {
            $pdo->exec('BEGIN IMMEDIATE');
        }
        try {
            $result = $fn($pdo);
            self::isMysql() ? $pdo->commit() : $pdo->exec('COMMIT');
            return $result;
        } catch (\Throwable $e) {
            self::isMysql() ? $pdo->rollBack() : $pdo->exec('ROLLBACK');
            throw $e;
        }
    }
}
