<?php
declare(strict_types=1);

use App\{ApiError, Auth, Database, Finanzas};
use Psr\Http\Message\ResponseInterface as Res;
use Psr\Http\Message\ServerRequestInterface as Req;
use Slim\Factory\AppFactory;
use Slim\Routing\RouteCollectorProxy;

require __DIR__ . '/../vendor/autoload.php';

$path = parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH) ?: '/';

/* ---------- Archivos del frontend (Vue ya compilado) ---------- */
if (!str_starts_with($path, '/api/')) {
    if (PHP_SAPI === 'cli-server' && $path !== '/' && is_file(__DIR__ . $path)) return false;
    header('Content-Type: text/html; charset=utf-8');
    $index = __DIR__ . '/index.html';
    if (is_file($index)) { readfile($index); exit; }
    echo '<p style="font-family:sans-serif">Falta compilar el frontend: ejecuta <code>npm run build</code> en la carpeta frontend.</p>';
    exit;
}

/* ---------- Sesión segura (OWASP / manual de PHP) ---------- */
ini_set('session.use_strict_mode', '1');
ini_set('session.use_only_cookies', '1');
session_name('misfinanzas');
session_set_cookie_params([
    'lifetime' => 0,
    'path' => '/',
    'httponly' => true,
    'secure' => !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off',
    'samesite' => 'Lax',
]);
session_start();

$app = AppFactory::create();
$app->addBodyParsingMiddleware();
$app->addRoutingMiddleware();

/* ---------- Respuestas JSON ---------- */
function json(Res $res, mixed $data, int $status = 200): Res
{
    $res->getBody()->write(json_encode($data, JSON_UNESCAPED_UNICODE | JSON_PRESERVE_ZERO_FRACTION));
    return $res->withHeader('Content-Type', 'application/json; charset=utf-8')
               ->withHeader('Cache-Control', 'no-store')
               ->withStatus($status);
}
function body(Req $req): array { return (array) ($req->getParsedBody() ?? []); }
function usuario(): int
{
    $id = Auth::usuarioId();
    if (!$id) throw new ApiError('Tu sesión terminó. Vuelve a iniciar sesión.', 401);
    return $id;
}
/** Ejecuta una operación del usuario dentro de una transacción. */
function op(callable $fn): mixed
{
    $uid = usuario();
    return Database::transaction($uid, fn($db) => $fn(new Finanzas($db, $uid)));
}

/* ---------- Errores con mensajes claros ---------- */
$errors = $app->addErrorMiddleware(false, true, true);
$errors->setDefaultErrorHandler(function (Req $req, Throwable $e) use ($app) {
    $res = $app->getResponseFactory()->createResponse();
    if ($e instanceof ApiError) return json($res, ['error' => $e->getMessage()], $e->status);
    if ($e instanceof Slim\Exception\HttpNotFoundException) return json($res, ['error' => 'Ruta no encontrada.'], 404);
    if ($e instanceof Slim\Exception\HttpMethodNotAllowedException) return json($res, ['error' => 'Método no permitido.'], 405);
    error_log((string) $e);
    $msg = $e instanceof PDOException ? 'No pude conectarme a la base de datos. Revisa config.php.' : 'Algo salió mal en el servidor. Intenta de nuevo.';
    return json($res, ['error' => $msg], 500);
});

/* ---------- Protección CSRF: solo aceptamos JSON en escrituras ---------- */
$app->add(function (Req $req, $handler) use ($app) {
    if (in_array($req->getMethod(), ['POST', 'PUT', 'PATCH', 'DELETE'], true)
        && !str_contains($req->getHeaderLine('Content-Type'), 'application/json')) {
        return json($app->getResponseFactory()->createResponse(), ['error' => 'Las peticiones deben enviarse en JSON.'], 415);
    }
    return $handler->handle($req);
});

/* ---------- Rutas ---------- */
$app->group('/api', function (RouteCollectorProxy $api) {

    // Autenticación
    $api->post('/auth/registro', fn(Req $q, Res $r) => json($r, Auth::registrar(Database::pdo(), body($q)), 201));
    $api->post('/auth/login', fn(Req $q, Res $r) => json($r, Auth::login(Database::pdo(), body($q))));
    $api->post('/auth/salir', function (Req $q, Res $r) { Auth::salir(); return json($r, ['ok' => true]); });
    $api->get('/auth/yo', fn(Req $q, Res $r) => json($r, ['usuario' => Auth::yo(Database::pdo())]));

    $api->get('/categorias', fn(Req $q, Res $r) => json($r, (new Finanzas(Database::pdo(), usuario()))->categorias()));
    $api->get('/resumen', fn(Req $q, Res $r) => json($r, op(fn($f) => $f->resumen($q->getQueryParams()['mes'] ?? null))));
    $api->get('/saldo', fn(Req $q, Res $r) => json($r, op(fn($f) => $f->totales())));

    // Ingresos y gastos (misma estructura)
    foreach (['ingresos', 'gastos'] as $t) {
        $api->get("/$t", fn(Req $q, Res $r) => json($r, op(fn($f) => $f->listarMovimientos($t, $q->getQueryParams()['mes'] ?? null))));
        $api->post("/$t", fn(Req $q, Res $r) => json($r, op(fn($f) => $f->crearMovimiento($t, body($q))), 201));
        $api->delete("/$t/{id:[0-9]+}", fn(Req $q, Res $r, array $a) => json($r, op(function ($f) use ($t, $a) { $f->eliminarMovimiento($t, (int) $a['id']); return ['ok' => true]; })));
    }
    $api->post('/gastos/copiar-fijos', fn(Req $q, Res $r) => json($r, op(fn($f) => $f->copiarFijos((string) (body($q)['mes'] ?? '')))));

    // Préstamos
    $api->get('/prestamos', fn(Req $q, Res $r) => json($r, op(fn($f) => $f->listarPrestamos())));
    $api->post('/prestamos', fn(Req $q, Res $r) => json($r, op(fn($f) => $f->crearPrestamo(body($q))), 201));
    $api->post('/prestamos/{id:[0-9]+}/abonos', fn(Req $q, Res $r, array $a) => json($r, op(fn($f) => $f->abonar((int) $a['id'], body($q))), 201));
    $api->delete('/prestamos/{id:[0-9]+}', fn(Req $q, Res $r, array $a) => json($r, op(function ($f) use ($a) { $f->eliminarPrestamo((int) $a['id']); return ['ok' => true]; })));

    // Ahorros
    $api->get('/metas', fn(Req $q, Res $r) => json($r, op(fn($f) => $f->listarMetas())));
    $api->post('/metas', fn(Req $q, Res $r) => json($r, op(fn($f) => $f->crearMeta(body($q))), 201));
    $api->post('/metas/{id:[0-9]+}/movimientos', fn(Req $q, Res $r, array $a) => json($r, op(fn($f) => $f->moverAhorro((int) $a['id'], body($q))), 201));
    $api->delete('/metas/{id:[0-9]+}', fn(Req $q, Res $r, array $a) => json($r, op(function ($f) use ($a) { $f->eliminarMeta((int) $a['id']); return ['ok' => true]; })));

    // Cuenta
    $api->post('/demo', fn(Req $q, Res $r) => json($r, op(function ($f) { $f->cargarEjemplo(); return ['ok' => true]; })));
    $api->delete('/datos', fn(Req $q, Res $r) => json($r, op(function ($f) { $f->borrarTodo(); return ['ok' => true]; })));
});

$app->run();
